# What only your phone can confirm (10 minutes)
Deploy first (see PWA.md), then open the https link in Chrome on your Android phone.
1. Install: Chrome menu > Install app. Open from the home-screen icon. Full screen? Icon looks right?
2. Chat: send "Hello". A reply streams in (confirms your real OpenAI key). Try a Bangla message.
3. Voice: Voice tab > tap mic > allow microphone > say "add task buy milk". Task appears? Then say "what time is it" and hear the answer.
4. Bangla voice: Settings > Language > বাংলা, tap mic, say a short Bangla sentence. (Needs a Bangla voice installed for speech output.)
5. Apps: type or say "open YouTube", "navigate to <your city>", "open WhatsApp". Does the app open, or does it say it couldn't confirm?
6. Share: say "share hello", tap Confirm. Does the Android share sheet appear?
7. Notifications: Settings > App > Notifications > allow. Say "remind me to test in 1 minute", leave the app open on screen. Do you get an alert?
8. Offline: turn on airplane mode, reopen the app. Do tasks, notes, calculator work? Does chat say it needs internet?
9. Reload test: add a task and a note, close the app completely, reopen. Still there?
10. Lock: Settings > Privacy > app lock with a PIN, close and reopen.
Tell me which steps fail and what you see, and I will fix them.
