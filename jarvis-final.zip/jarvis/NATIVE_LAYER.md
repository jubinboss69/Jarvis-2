# Optional Android native layer (design, not built or tested)

A PWA can only open apps through links. A thin native wrapper (Capacitor) adds real device control. The client already looks for `window.Capacitor.Plugins.JarvisDevice` and uses it when present; otherwise it falls back to links.

## What the web app cannot do (needs this layer)
- Launch any installed app by package name and know if it opened
- Open phone settings screens (Wi-Fi, Bluetooth, display)
- List or check installed apps
- Listen for the wake word in the background (foreground service)

## Plugin contract
- `launchApp({package, url?}) -> {opened: boolean}`: `getLaunchIntentForPackage`, else open `url` as VIEW intent.
- `isInstalled({package}) -> {installed: boolean}`
- `openSettings({action}) -> {opened: boolean}`: whitelist such as `android.settings.WIFI_SETTINGS`, `BLUETOOTH_SETTINGS`, `DISPLAY_SETTINGS`.

## Kotlin sketch
```kotlin
@CapacitorPlugin(name = "JarvisDevice")
class JarvisDevicePlugin : Plugin() {
  @PluginMethod fun launchApp(call: PluginCall) {
    val pkg = call.getString("package") ?: return call.reject("package required")
    val i = context.packageManager.getLaunchIntentForPackage(pkg)
    if (i == null) { call.resolve(JSObject().put("opened", false)); return }
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i)
    call.resolve(JSObject().put("opened", true))
  }
}
```
Android 11+ needs `<queries><package android:name="com.whatsapp"/>...</queries>` in the manifest for each app you want to detect. Avoid QUERY_ALL_PACKAGES (Play policy).

## Build steps
1. `npm i @capacitor/core @capacitor/android`, `npx cap init`, point `server.url` at your deployed JARVIS address.
2. `npx cap add android`, add the plugin class, register it in `MainActivity`.
3. Build the APK in Android Studio.
