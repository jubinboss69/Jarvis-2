
const S=[["home","Home","M3 11l9-8 9 8v10H3z"],["chat","Chat","M4 5h16v11H8l-4 4z"],["voice","Voice","M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3zM6 11a6 6 0 0 0 12 0M12 17v4"],["tools","Tools","M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"],["settings","Settings","M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM3 12h3M18 12h3M12 3v3M12 18v3"]];
const $=id=>document.getElementById(id);
$("nav").innerHTML=S.map(s=>`<button data-go="${s[0]}"><svg viewBox="0 0 24 24"><path d="${s[2]}"/></svg>${s[1]}</button>`).join("");
let CURS="home";function go(id){CURS=id;if(id==="settings"&&typeof storInfo==="function"){storInfo();storUse()}setTimeout(translateUI,0);if(id!=="tool")clearInterval(TMR);if(id!=="voice"){stopRec();stopSpeak()}else if(ST.wake)startRec(true);document.querySelectorAll(".screen").forEach(e=>e.classList.toggle("on",e.id===id));const g=(id==="tasks"||id==="notes"||id==="apps"||id==="tool")?"tools":id==="about"?"settings":id;document.querySelectorAll("nav button").forEach(b=>{b.classList.toggle("on",b.dataset.go===g);if(b.dataset.go===g)b.setAttribute("aria-current","page");else b.removeAttribute("aria-current")});document.querySelector("main").scrollTop=0}
document.addEventListener("click",e=>{const b=e.target.closest("[data-go]");if(b)go(b.dataset.go);const q=e.target.closest("[data-q]");if(q){go("chat");$("cin").value=q.dataset.q;$("cin").focus()}const a=e.target.closest("[data-ac]");if(a){ST.ac=a.dataset.ac;save();apply()}});
const tasks=[],notes=[];
const esc=t=>{const d=document.createElement("div");d.textContent=t;return d.innerHTML};
function stats(){$("sTasks").textContent=tasks.filter(t=>!t.d).length;$("sNotes").textContent=notes.length}
function head(){const h=new Date().getHours(),bn=ST.lang==="bn",n=ST.name||"JARVIS";const g=h<12?(bn?"শুভ সকাল":"Good morning"):h<18?(bn?"শুভ বিকাল":"Good afternoon"):(bn?"শুভ সন্ধ্যা":"Good evening");$("greet").innerHTML=g+(ST.me?", "+esc(ST.me):"")+",<br><i>"+esc(ST.greet||"at your service")+"</i>";$("clock").textContent=new Date().toLocaleDateString(bn?"bn-BD":undefined,{weekday:"long",month:"long",day:"numeric"});document.querySelectorAll(".nm").forEach(x=>x.textContent=n)}
function addMsg(t,c){const d=document.createElement("div");d.className="m "+c;let r=d;if(c==="me")d.textContent=t;else{d.innerHTML='<div class="av"></div><div></div>';r=d.lastChild;r.textContent=t}$("msgs").appendChild(d);document.querySelector("main").scrollTop=1e5;return r}
const fmtBytes=n=>n<1024?n+" B":n<1048576?(n/1024).toFixed(1)+" KB":(n/1048576).toFixed(1)+" MB";
const DB=(()=>{let db=null,mode="indexeddb",last=new Map(),Q=Promise.resolve(),warned=false,failed=false;
 const run=fn=>{Q=Q.then(fn).catch(()=>{failed=true;if(!warned){warned=true;try{toast("Storage is full or blocked. Changes may not be saved.")}catch(e){}}});return Q};
 const tx=(names,rw,fn)=>new Promise((res,rej)=>{const t=db.transaction(names,rw?"readwrite":"readonly");const r=fn(t);t.oncomplete=()=>res(r&&r.result);t.onerror=t.onabort=()=>rej(t.error)});
 const lsGet=k=>{try{return JSON.parse(localStorage.getItem("jvdb_"+k))}catch(e){return null}};
 const lsSet=(k,v)=>localStorage.setItem("jvdb_"+k,JSON.stringify(v));
 return{
  get mode(){return mode},get failed(){return failed},flush(){return Q},
  open(){return new Promise(res=>{if(!window.indexedDB){mode="localStorage";return res()}let q;try{q=indexedDB.open("jarvis",1)}catch(e){mode="localStorage";return res()}
   q.onupgradeneeded=()=>{q.result.createObjectStore("kv");q.result.createObjectStore("chats",{keyPath:"id"})};
   q.onsuccess=()=>{db=q.result;db.onversionchange=()=>db.close();res()};q.onerror=q.onblocked=()=>{mode="localStorage";res()}})},
  async get(k,d){if(mode!=="indexeddb"){const v=lsGet(k);return v===null?d:v}try{const v=await tx(["kv"],false,t=>t.objectStore("kv").get(k));return v===undefined?d:v}catch(e){return d}},
  set(k,v){const s=JSON.stringify(v);if(last.get(k)===s)return Q;last.set(k,s);return run(()=>mode!=="indexeddb"?lsSet(k,v):tx(["kv"],true,t=>{t.objectStore("kv").put(JSON.parse(s),k)}))},
  remember(k,v){last.set(k,JSON.stringify(v))},
  async chats(){if(mode!=="indexeddb")return lsGet("chats")||[];try{return(await tx(["chats"],false,t=>t.objectStore("chats").getAll()))||[]}catch(e){return[]}},
  rememberChats(l){l.forEach(c=>last.set("chat:"+c.id,JSON.stringify(c)))},
  syncChats(list){const jobs=[],ids=new Set(list.map(c=>"chat:"+c.id));for(const c of list){const s=JSON.stringify(c),k="chat:"+c.id;if(last.get(k)!==s){last.set(k,s);jobs.push(["put",c])}}
   for(const k of [...last.keys()])if(k.startsWith("chat:")&&!ids.has(k)){last.delete(k);jobs.push(["del",+k.slice(5)])}
   if(!jobs.length)return Q;return run(()=>mode!=="indexeddb"?lsSet("chats",list):tx(["chats"],true,t=>{const s=t.objectStore("chats");for(const[j,x]of jobs)j==="put"?s.put(JSON.parse(JSON.stringify(x))):s.delete(x)}))},
  clearChats(){for(const k of [...last.keys()])if(k.startsWith("chat:"))last.delete(k);return run(()=>mode!=="indexeddb"?localStorage.removeItem("jvdb_chats"):tx(["chats"],true,t=>{t.objectStore("chats").clear()}))},
  async clearAll(){last.clear();await Q;if(mode==="indexeddb"&&db)await run(()=>tx(["kv","chats"],true,t=>{t.objectStore("kv").clear();t.objectStore("chats").clear()}));Object.keys(localStorage).filter(k=>k.startsWith("jvdb_")).forEach(k=>localStorage.removeItem(k))}}})();
let CH=[],CUR=null,busy=false;
function saveCH(){if(!ST.hist)return;DB.syncChats(CH.filter(c=>c.msgs.length))}
function cur(){let c=CH.find(x=>x.id===CUR);if(!c){c={id:Date.now(),title:"New chat",msgs:[]};CH.unshift(c);CUR=c.id}return c}
function renderChat(){const c=cur();$("msgs").innerHTML="";if(!c.msgs.length)addMsg("Hello, I'm "+ST.name+". How can I help?","ai");c.msgs.forEach(m=>addMsg(m.content,m.role==="user"?"me":"ai"))}
function rH(){const l=CH.filter(c=>c.msgs.length);$("hlist").innerHTML=l.length?l.map(c=>`<div class="row"><span class="sp" data-o="${c.id}" style="cursor:pointer">${esc(c.title)}</span><button data-rn="${c.id}" style="background:none;border:0;color:var(--mu);font-size:16px">✎</button><button data-dc="${c.id}" style="background:none;border:0;color:var(--mu);font-size:18px">✕</button></div>`).join(""):'<div class="row"><span class="muted">No chats yet.</span></div>'}
$("hist").onclick=()=>{rH();const h=$("hlist");h.style.display=h.style.display==="none"?"block":"none"};
$("newc").onclick=()=>{if(cur().msgs.length){CUR=null;cur()}renderChat();$("hlist").style.display="none"};
$("hlist").onclick=e=>{const t=e.target.dataset;if(t.rn){const c=CH.find(x=>x.id==+t.rn),n=c&&prompt("Rename chat",c.title);if(n&&n.trim()){c.title=n.trim().slice(0,60);saveCH();rH()}}if(t.o){CUR=+t.o;renderChat();$("hlist").style.display="none"}if(t.dc){CH=CH.filter(c=>c.id!=+t.dc);if(CUR==+t.dc)CUR=null;saveCH();cur();renderChat();rH()}};
async function send(v,viaVoice){v=v.trim();if(!v||busy)return;if(!viaVoice)go("chat");if(viaVoice)$("vans").textContent="Thinking…";const c=cur();c.msgs.push({role:"user",content:v});c.upd=Date.now();if(c.title==="New chat")c.title=v.slice(0,40);addMsg(v,"me");const box=addMsg("…","ai");busy=true;let out="";
 try{
  const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json","x-access-code":localStorage.getItem("jvcode")||""},body:JSON.stringify({messages:c.msgs.slice(-20),settings:{name:ST.name,lang:ST.lang,model:ST.model,temp:ST.temp,style:ST.style,me:ST.me,about:ST.about}})});
  if(r.status===401){const code=prompt("Enter your access code");if(code)localStorage.setItem("jvcode",code);throw new Error("Access code needed. Send your message again.")}
  if(r.status===404||r.status===405)throw new Error("Failed to fetch");
  if(!r.ok)throw new Error((await r.json().catch(()=>({}))).error||"Server error ("+r.status+")");
  const rd=r.body.getReader(),dec=new TextDecoder();let buf="";
  for(;;){const {done,value}=await rd.read();if(done)break;buf+=dec.decode(value,{stream:true});let i;while((i=buf.indexOf("\n\n"))>=0){const ln=buf.slice(0,i).trim();buf=buf.slice(i+2);if(!ln.startsWith("data:"))continue;const d=ln.slice(5).trim();if(d==="[DONE]")continue;const j=JSON.parse(d);if(j.error)throw new Error(j.error);out+=j.t;box.textContent=out;document.querySelector("main").scrollTop=1e5}}
  c.msgs.push({role:"assistant",content:out||"(no reply)"});
 }catch(e){box.textContent=e.message==="Failed to fetch"?"Can't reach the JARVIS server. Chat needs internet; your notes, tasks and tools still work offline.":e.message;box.style.color="#ff8aa0";c.msgs.pop()}
 busy=false;saveCH();rH();if(viaVoice){$("vans").textContent=out||box.textContent;if(out&&ST.voice)speak(out,resumeWake);else resumeWake()}}
$("send").onclick=()=>{ask($("cin").value);$("cin").value=""};$("cin").onkeydown=e=>{if(e.key==="Enter")$("send").click()};
$("hgo").onclick=()=>{ask($("hin").value);$("hin").value=""};$("hin").onkeydown=e=>{if(e.key==="Enter")$("hgo").click()};
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
let rec=null,recWake=false,listening=false,spk=false,blocked=false;
const langCode=()=>ST.lang==="bn"?"bn-BD":"en-US";
//<pure>
function parseCmd(t){const s=t.trim().replace(/[.!?]+$/,"");let m;
 if(/^(stop|cancel|be quiet|quiet|থামো|থামুন)$/i.test(s))return{k:"stop"};
 if(m=s.match(/^go to (home|chat|voice|tools|tasks|notes|settings|apps)$/i))return{k:"go",a:m[1].toLowerCase()};
 if(m=s.match(/^(?:add (?:a )?task|new task)[: ]+(.+)$/i))return{k:"task",a:m[1]};
 if(m=s.match(/^(?:take a note|make a note|add (?:a )?note|note)[: ]+(.+)$/i))return{k:"note",a:m[1]};
 if(/^(new chat|start over|start a new chat)$/i.test(s))return{k:"new"};
 if(m=s.match(/^translate\s+(.+?)\s+(?:to|into)\s+(english|bangla|bengali|hindi|urdu|arabic|spanish|french|german|chinese|japanese)$/i))return{k:"translate",a:[m[1],langName(m[2])]};
 if(m=s.match(/^translate\s+(?:to|into)\s+(english|bangla|bengali|hindi|urdu|arabic|spanish|french|german|chinese|japanese)[: ]+(.+)$/i))return{k:"translate",a:[m[2],langName(m[1])]};
 if(m=s.match(/^summari[sz]e(?: this(?: text)?)?[: ]+(.+)$/i))return{k:"summarize",a:[m[1]]};
 if(m=s.match(/^(?:calculate|calc|compute|what(?:'s| is))\s+(\d+(?:\.\d+)?)\s*(?:%|percent)\s+of\s+(\d+(?:\.\d+)?)$/i))return{k:"calc",a:"("+m[1]+"/100)*"+m[2]};
 if(m=s.match(/^(?:calculate|calc|compute)\s+(.+)$/i))return{k:"calc",a:m[1]};
 if(m=s.match(/^convert\s+(-?\d+(?:\.\d+)?)\s*([a-z°²/]+?)\s+(?:to|in|into)\s+([a-z°²/]+)$/i))return{k:"convert",a:[m[1],m[2],m[3]]};
 if(/^(?:what(?:'s| is) (?:the )?(?:current )?(?:time|date)(?: now| today)?|what time is it(?: now)?|what day is it(?: today)?|time now|current time)$/i.test(s))return{k:"time"};
 if(m=s.match(/^(?:(?:what(?:'s| is)|how(?:'s| is)) the )?weather(?: like)?(?: (?:in|for|at) (.+))?$/i))return{k:"weather",a:(m[1]||"").replace(/\s+(today|now)$/i,"")};
 if(m=s.match(/^remind me (?:to |about )?(.+)$/i))return{k:"remind",a:m[1]};
 if(m=s.match(/^(?:add event|schedule|add to calendar)[: ]+(.+)$/i))return{k:"event",a:m[1]};
 if(/^[\d\s+\-*/^().%×÷]+$/.test(s)&&/\d/.test(s)&&/[+\-*/^×÷]/.test(s))return{k:"calc",a:s};
 if(m=s.match(/^(?:search youtube for|play)\s+(.+?)(?:\s+on youtube)?$/i))return{k:"yt",a:m[1]};
 if(m=s.match(/^(?:search(?: the web| google)?(?: for)?|google|look up)\s+(.+)$/i))return{k:"search",a:m[1]};
 if(m=s.match(/^(?:navigate to|directions to|take me to|map of)\s+(.+)$/i)||s.match(/^(?:show|find)\s+(.+?)\s+on\s+(?:the\s+)?maps?$/i))return{k:"map",a:m[1]};
 if(m=s.match(/^copy[: ]+(.+)$/i))return{k:"copy",a:m[1]};
 if(m=s.match(/^share[: ]+(.+)$/i))return{k:"share",a:m[1]};
 if(m=s.match(/^(?:call|dial|phone)\s+([+\d][\d\s\-()]{4,})$/i))return{k:"call",a:m[1].replace(/[^\d+]/g,"")};
 if(m=s.match(/^email\s+([^\s@]+@[^\s@]+\.[^\s@]+)$/i))return{k:"mail",a:m[1]};
 if(/^(?:open|launch)\s+(?:the\s+)?(?:phone\s+|wi-?fi\s+|bluetooth\s+|display\s+|sound\s+)?settings?$/i.test(s))return{k:"phoneset"};
 if(m=s.match(/^(?:open|launch|start)\s+(.+)$/i))return{k:"open",a:m[1]};
 return{k:"ai"}}
function toIntent(url,pkg,fb){const u=new URL(url),f=fb||(/^https?:$/.test(u.protocol)?url:"");return"intent://"+u.host+u.pathname+u.search+"#Intent;scheme="+u.protocol.slice(0,-1)+";package="+pkg+(f?";S.browser_fallback_url="+encodeURIComponent(f):"")+";end"}
function norm(s){return s.toLowerCase().replace(/^(the|my)\s+/,"").replace(/\s+(app|application)$/,"").trim()}
function findApp(name,apps){const n=norm(name);return apps.find(a=>a.al.includes(n))||null}
function isDomain(s){return/^(https?:\/\/)?[a-z0-9-]+(\.[a-z0-9-]+)*\.[a-z]{2,}(\/\S*)?$/i.test(s.trim())}
function siteUrl(s){s=s.trim();return/^https?:\/\//i.test(s)?s:"https://"+s}
function validApp(n,l,p){n=(n||"").trim();l=(l||"").trim();p=(p||"").trim();if(!n||n.length>30)return"Enter a name (up to 30 characters).";if(/^(file|blob|data|javascript|vbscript|about|content):/i.test(l))return"That link type isn't allowed.";if(!/^[a-z][a-z0-9+.-]*:\/\/\S+$/i.test(l))return"Enter a valid link like https://example.com or myapp://open.";if(p&&!/^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$/i.test(p))return"The Android package should look like com.example.app.";return""}
const fmt=x=>String(+Number(x).toPrecision(12));
const iso=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
const LANGS=["English","Bangla","Hindi","Urdu","Arabic","Spanish","French","German","Chinese","Japanese"];
function langName(s){s=s.toLowerCase();if(s==="bengali")s="bangla";return LANGS.find(l=>l.toLowerCase()===s)||null}
function wmo(c){return c===0?"Clear sky":c<=2?"Partly cloudy":c===3?"Overcast":c<=48?"Fog":c<=57?"Drizzle":c<=67?"Rain":c<=77?"Snow":c<=82?"Rain showers":c<=86?"Snow showers":"Thunderstorm"}
function calc(src){const s=String(src).toLowerCase().replace(/×/g,"*").replace(/÷/g,"/").replace(/\s+/g,"");if(!s||s.length>200)throw new Error("Nothing to calculate");let i=0;
 const F={sqrt:Math.sqrt,sin:x=>Math.sin(x*Math.PI/180),cos:x=>Math.cos(x*Math.PI/180),tan:x=>Math.tan(x*Math.PI/180),log:Math.log10,ln:Math.log,abs:Math.abs};
 const ex=()=>{let v=tm();while(s[i]==="+"||s[i]==="-"){const o=s[i++],r=tm();v=o==="+"?v+r:v-r}return v};
 const tm=()=>{let v=un();while(s[i]==="*"||s[i]==="/"){const o=s[i++],r=un();v=o==="*"?v*r:v/r}return v};
 const un=()=>{if(s[i]==="-"){i++;return-un()}if(s[i]==="+"){i++;return un()}return pw()};
 const pw=()=>{const b=po();if(s[i]==="^"){i++;return Math.pow(b,un())}return b};
 const po=()=>{let v=pr();while(s[i]==="%"){i++;v/=100}return v};
 const pr=()=>{if(s[i]==="("){i++;const v=ex();if(s[i++]!==")")throw new Error("Missing )");return v}
  const m=s.slice(i).match(/^(\d+\.?\d*|\.\d+)/);if(m){i+=m[0].length;return parseFloat(m[0])}
  const w=s.slice(i).match(/^[a-z]+/);if(w){const n=w[0];i+=n.length;if(n==="pi")return Math.PI;if(n==="e")return Math.E;if(!F[n])throw new Error("Unknown "+n);if(s[i++]!=="(")throw new Error("Missing (");const v=ex();if(s[i++]!==")")throw new Error("Missing )");return F[n](v)}
  throw new Error("Unexpected "+(s[i]||"end"))};
 const r=ex();if(i<s.length)throw new Error("Unexpected "+s[i]);if(!isFinite(r))throw new Error("Not a number");return +r.toPrecision(12)}
const UNITS={length:{m:1,km:1000,cm:.01,mm:.001,mi:1609.344,yd:.9144,ft:.3048,in:.0254},mass:{kg:1,g:.001,mg:1e-6,lb:.45359237,oz:.028349523125},volume:{l:1,ml:.001,gal:3.785411784,cup:.2365882365,floz:.0295735295625},speed:{"m/s":1,"km/h":1/3.6,mph:.44704,kn:.514444},area:{"m²":1,"km²":1e6,ha:1e4,acre:4046.8564224,"ft²":.09290304},data:{B:1,KB:1024,MB:1048576,GB:1073741824,TB:1099511627776},time:{s:1,min:60,h:3600,day:86400},temp:null};
const UA={kilometers:"km",kilometres:"km",kilometer:"km",kilometre:"km",meters:"m",metres:"m",meter:"m",metre:"m",centimeters:"cm",centimetres:"cm",millimeters:"mm",miles:"mi",mile:"mi",yards:"yd",yard:"yd",feet:"ft",foot:"ft",inches:"in",inch:"in",kilograms:"kg",kilogram:"kg",kilos:"kg",grams:"g",gram:"g",pounds:"lb",pound:"lb",lbs:"lb",ounces:"oz",ounce:"oz",liters:"l",litres:"l",liter:"l",litre:"l",milliliters:"ml",gallons:"gal",gallon:"gal",cups:"cup",celsius:"C",fahrenheit:"F",kelvin:"K",c:"C",f:"F",k:"K",kph:"km/h",kmh:"km/h",knots:"kn",seconds:"s",minutes:"min",hours:"h",hrs:"h",days:"day",acres:"acre",hectares:"ha",bytes:"B"};
function unitOf(u){const x=u.trim(),k=UA[x.toLowerCase()]||x;if(k==="C"||k==="F"||k==="K")return{cat:"temp",u:k};for(const c in UNITS){const t=UNITS[c];if(t){const h=Object.keys(t).find(n=>n===k||n.toLowerCase()===k.toLowerCase());if(h)return{cat:c,u:h}}}return null}
function convert(v,from,to,cat){if(cat==="temp"){const c=from==="C"?v:from==="F"?(v-32)*5/9:v-273.15;return to==="C"?c:to==="F"?c*9/5+32:c+273.15}const t=UNITS[cat];if(!t||!(from in t)||!(to in t))throw new Error("Unknown unit");return v*t[from]/t[to]}
function parseWhen(text,now){let t=" "+text+" ",m;const cut=r=>{t=t.replace(r," ")},none={when:null,timed:false,rest:text.trim()},fin=(d,timed)=>({when:d,timed,rest:t.replace(/\s+/g," ").replace(/^\s*(?:to|at|on|for)\s+|\s+(?:to|at|on|for)\s*$/gi,"").trim()});
 if(m=t.match(/\bin\s+(\d+(?:\.\d+)?)\s*(minutes?|mins?|hours?|hrs?|h|days?)\b/i)){const n=parseFloat(m[1]),u=m[2][0].toLowerCase();cut(m[0]);return fin(new Date(now+n*(u==="m"?6e4:u==="d"?864e5:36e5)),true)}
 const b=new Date(now);let day=null;
 if(m=t.match(/\b(?:on\s+)?(\d{4})-(\d{2})-(\d{2})\b/)){b.setFullYear(+m[1],+m[2]-1,+m[3]);day=0;cut(m[0])}
 else if(/\btomorrow\b/i.test(t)){day=1;cut(/\btomorrow\b/i)}
 else if(/\b(?:today|tonight)\b/i.test(t)){day=0;cut(/\b(?:today|tonight)\b/i)}
 else if(m=t.match(/\b(?:on\s+|next\s+)?(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/i)){const w=["sunday","monday","tuesday","wednesday","thursday","friday","saturday"].indexOf(m[1].toLowerCase());day=(w-b.getDay()+7)%7||7;cut(m[0])}
 let hh=null,mi=0,ap=null;
 if(m=t.match(/\bat\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b/i)||t.match(/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/i)){hh=+m[1];mi=+(m[2]||0);ap=m[3]&&m[3].toLowerCase();cut(m[0])}
 if(hh===null&&day===null)return none;if(hh!==null&&(hh>23||mi>59))return none;
 if(day)b.setDate(b.getDate()+day);
 const mk=h=>{const d=new Date(b);d.setHours(h,mi,0,0);return d};let d;
 if(hh===null)d=mk(9);else{if(ap==="pm"&&hh<12)hh+=12;if(ap==="am"&&hh===12)hh=0;d=mk(hh);if(!ap&&hh>=1&&hh<=11&&day===null&&d.getTime()<=now){const d2=mk(hh+12);if(d2.getTime()>now)d=d2}}
 if(d.getTime()<=now){if(day===null)d.setDate(d.getDate()+1);else return none}
 return fin(d,hh!==null)}
//</pure>
const cap=x=>x.charAt(0).toUpperCase()+x.slice(1);
function err(e){const m={"not-allowed":"Microphone permission is blocked. Allow it in your browser's site settings.","service-not-allowed":"Speech recognition is blocked on this browser.","no-speech":"I didn't hear anything. Tap the mic and try again.","network":"Speech recognition needs an internet connection.","language-not-supported":"This language isn't supported for speech input on this device.","audio-capture":"No microphone found.",unsupported:"This browser doesn't support speech recognition. Use Chrome on Android."};if(["not-allowed","service-not-allowed","audio-capture","unsupported"].includes(e))blocked=true;$("vnote").textContent=m[e]||"Speech error: "+e}
function setL(on,wake){listening=on;$("mic").classList.toggle("on",on&&!wake);$("core2").classList.toggle("listen",on);$("vstat").textContent=on?(wake?"Waiting for “"+ST.name+"”…":"Listening…"):(spk?"Speaking…":"Tap the mic and speak.")}
function startRec(wake){if(!SR||blocked)return;stopRec();const r=new SR();rec=r;recWake=!!wake;r.lang=langCode();r.interimResults=true;r.continuous=!!wake;let fin="";
 r.onstart=()=>setL(true,wake);
 r.onresult=e=>{let t="";for(let i=e.resultIndex;i<e.results.length;i++){const x=e.results[i][0].transcript;t+=x;if(e.results[i].isFinal){if(wake){const low=x.toLowerCase(),k=[ST.name.toLowerCase(),"jarvis"].find(w=>w&&low.includes(w));if(k){const rest=x.slice(low.indexOf(k)+k.length).replace(/^[\s,.:!]+/,"");stopRec();if(rest)handle(rest);else{$("vtxt").textContent="";startRec(false)}return}}else fin+=x}}if(!wake)$("vtxt").textContent=t};
 r.onerror=e=>{if(e.error!=="aborted"&&!(wake&&e.error==="no-speech"))err(e.error)};
 r.onend=()=>{if(rec!==r)return;rec=null;setL(false);if(!wake&&fin.trim())handle(fin.trim());else if(wake&&ST.wake&&CURS==="voice"&&document.visibilityState==="visible"&&!blocked)setTimeout(()=>{if(!rec&&!spk&&!busy)startRec(true)},400)};
 try{r.start()}catch(e){err("start")}}
function stopRec(){if(rec){const r=rec;rec=null;r.onresult=r.onerror=r.onend=null;try{r.abort()}catch(e){}}setL(false)}
function resumeWake(){if(ST.wake&&CURS==="voice"&&SR&&!spk&&!busy)startRec(true)}
function pickVoice(l){const p=l==="bn"?"bn":"en";return(window.speechSynthesis?speechSynthesis.getVoices():[]).find(v=>v.lang.toLowerCase().startsWith(p))||null}
function checkVoices(){$("vnote").textContent=(!SR?"This browser doesn't support speech recognition. Use Chrome on Android.":(ST.lang==="bn"&&window.speechSynthesis&&speechSynthesis.getVoices().length&&!pickVoice("bn"))?"No Bangla voice found on this device. Install one in Android Settings > Text-to-speech.":"");if(!SR)blocked=true}
function speak(t,done){if(!window.speechSynthesis){done&&done();return}stopSpeak();const clean=t.replace(/```[\s\S]*?```/g," code block. ").replace(/[*#`_>]/g,"").slice(0,1500);const u=new SpeechSynthesisUtterance(clean);const l=/[\u0980-\u09FF]/.test(clean)?"bn":"en",v=chooseVoice(l);if(v)u.voice=v;u.lang=v?v.lang:(l==="bn"?"bn-BD":"en-US");u.rate=ST.rate;u.pitch=ST.pitch;
 u.onstart=()=>{spk=true;$("mic").classList.add("speak");setL(false)};
 u.onend=u.onerror=()=>{spk=false;$("mic").classList.remove("speak");setL(false);done&&done()};
 speechSynthesis.speak(u)}
function stopSpeak(){spk=false;$("mic").classList.remove("speak");try{window.speechSynthesis&&speechSynthesis.cancel()}catch(e){}}
function reply(m){out(m)}
const IS_ANDROID=/Android/i.test(navigator.userAgent);
const Native=(window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.JarvisDevice)||null;
const APPS0=[{id:"youtube",name:"YouTube",al:["youtube","you tube"],web:"https://www.youtube.com/",pkg:"com.google.android.youtube"},
{id:"google",name:"Google",al:["google"],web:"https://www.google.com/"},
{id:"gmail",name:"Gmail",al:["gmail","mail","email"],web:"https://mail.google.com/",pkg:"com.google.android.gm"},
{id:"maps",name:"Maps",al:["maps","google maps","map"],web:"https://www.google.com/maps",pkg:"com.google.android.apps.maps"},
{id:"whatsapp",name:"WhatsApp",al:["whatsapp","whats app"],web:"https://web.whatsapp.com/",link:"whatsapp://send",pkg:"com.whatsapp"},
{id:"telegram",name:"Telegram",al:["telegram"],web:"https://web.telegram.org/",link:"tg://resolve",pkg:"org.telegram.messenger"},
{id:"facebook",name:"Facebook",al:["facebook","fb"],web:"https://www.facebook.com/",pkg:"com.facebook.katana"},
{id:"instagram",name:"Instagram",al:["instagram","insta"],web:"https://www.instagram.com/",pkg:"com.instagram.android"},
{id:"spotify",name:"Spotify",al:["spotify"],web:"https://open.spotify.com/",pkg:"com.spotify.music"},
{id:"x",name:"X (Twitter)",al:["x","twitter"],web:"https://x.com/",pkg:"com.twitter.android"}];
let CAPPS=[];try{CAPPS=JSON.parse(localStorage.getItem("jvapps")||"[]")}catch(e){}
const allApps=()=>[...APPS0,...CAPPS];
function saveA(){try{localStorage.setItem("jvapps",JSON.stringify(CAPPS))}catch(e){}}
let PENDING=null;
function mkBtns(b){if(!b||!b.length)return null;const d=document.createElement("div");b.forEach(x=>{const e=document.createElement("button");e.className="btn sm"+(x.ghost?" ghost":"");e.textContent=x.label;e.onclick=()=>{if(!x.keep)e.disabled=true;x.fn()};d.appendChild(e)});return d}
function out(msg,btns){if(CURS==="tool"){toast(msg,btns);return}const box=addMsg(msg,"ai"),r=mkBtns(btns);if(r)box.appendChild(r);$("vans").textContent=msg;$("vact").innerHTML="";const r2=mkBtns(btns);if(r2)$("vact").appendChild(r2);if(ST.voice&&CURS==="voice")speak(msg,resumeWake);else resumeWake()}
function waitHidden(ms){return new Promise(res=>{const f=()=>{if(document.visibilityState==="hidden"){document.removeEventListener("visibilitychange",f);res(true)}};document.addEventListener("visibilitychange",f);setTimeout(()=>{document.removeEventListener("visibilitychange",f);res(false)},ms)})}
async function openTarget(label,o){
 if(Native&&o.pkg){try{const r=await Native.launchApp({package:o.pkg,url:o.link||o.web||""});return out(r&&r.opened?"Opened "+label+".":"Couldn't open "+label+".")}catch(e){return out("Couldn't open "+label+" ("+(e.message||"native error")+").")}}
 const target=IS_ANDROID?(o.link||o.web):(o.web||o.link);
 const go1=()=>{let u=target;if(IS_ANDROID&&o.pkg){try{u=toIntent(target,o.pkg,o.web)}catch(e){}}if(IS_ANDROID){location.href=u;return true}return!!window.open(u,"_blank","noopener")};
 const p=waitHidden(1800);if(!go1())return out("Your browser blocked opening "+label+".",[{label:"Open "+label,fn:go1}]);
 if(await p)return out("Opened "+label+".");
 out("I sent the request, but I couldn't confirm that "+label+" opened. It may not be installed, or the browser needs a tap.",[{label:"Open "+label,fn:go1}])}
function confirmAct(msg,fn){PENDING={fn};out(msg+" Say \u201cconfirm\u201d or tap Confirm.",[{label:"Confirm",fn:()=>{PENDING=null;fn()}},{label:"Cancel",ghost:true,fn:()=>{PENDING=null;out("Cancelled.")}}])}
const enc=encodeURIComponent;
async function runCmd(c){
 switch(c.k){
  case"stop":stopSpeak();$("vans").textContent="Stopped.";return resumeWake();
  case"go":return go(c.a);
  case"task":tasks.push({x:cap(c.a),d:false});rT();return out("Task added: "+cap(c.a));
  case"note":notes.unshift(cap(c.a));rN();return out("Note saved.");
  case"new":$("newc").click();return out("Started a new chat.");
  case"open":{const a=findApp(c.a,allApps());if(a)return openTarget(a.name,a);if(isDomain(c.a))return openTarget(c.a.trim(),{web:siteUrl(c.a)});return out("I don't have \u201c"+c.a+"\u201d in my app list. Add it under Tools > Apps & links, or say a website like \u201copen example.com\u201d.")}
  case"search":return openTarget("Google search",{web:"https://www.google.com/search?q="+enc(c.a)});
  case"yt":return openTarget("YouTube",{web:"https://www.youtube.com/results?search_query="+enc(c.a),pkg:"com.google.android.youtube"});
  case"map":return openTarget("Maps",{web:"https://www.google.com/maps/search/?api=1&query="+enc(c.a),pkg:"com.google.android.apps.maps"});
  case"phoneset":return out("Web apps can't open phone settings. That needs the optional native Android layer (see NATIVE_LAYER.md). You can open Settings from your phone's home screen or notification shade.");
  case"copy":if(!navigator.clipboard)return out("Copying isn't supported here. It needs a secure https page.");
   try{await navigator.clipboard.writeText(c.a);return out("Copied to the clipboard.")}catch(e){return out("The browser blocked clipboard access.",[{label:"Copy now",fn:()=>navigator.clipboard.writeText(c.a).catch(()=>{})}])}
  case"share":if(!navigator.share)return out("Sharing isn't supported on this browser.");
   return confirmAct("Share this text? \u201c"+c.a+"\u201d",async()=>{try{await navigator.share({text:c.a});out("The share sheet was shown.")}catch(e){out(e.name==="AbortError"?"Sharing was cancelled.":e.name==="NotAllowedError"?"The browser needs you to tap Confirm for sharing.":"Couldn't share.")}});
  case"calc":try{return out(c.a.trim()+" = "+fmt(calc(c.a)))}catch(e){return out("I couldn't calculate that: "+e.message)}
  case"convert":{const f=unitOf(c.a[1]),t=unitOf(c.a[2]);if(!f||!t||f.cat!==t.cat)return out("I can't convert between those units.");return out(c.a[0]+" "+f.u+" = "+fmt(convert(+c.a[0],f.u,t.u,f.cat))+" "+t.u)}
  case"time":{const n=new Date();return out(n.toLocaleTimeString([],{...HF(),hour:"numeric",minute:"2-digit"})+", "+n.toLocaleDateString([],{weekday:"long",month:"long",day:"numeric",year:"numeric"}))}
  case"weather":{const city=c.a||localStorage.getItem("jvcity")||"";if(!city)return out("Which city? Say \u201cweather in Dhaka\u201d.");try{const d=await api("/api/weather?city="+enc(city));return out(d.place+": "+Math.round(d.temp)+"\u00b0C, "+wmo(d.code).toLowerCase()+". Feels like "+Math.round(d.feels)+"\u00b0, humidity "+d.humidity+"%. Today "+Math.round(d.days[0].max)+"\u00b0/"+Math.round(d.days[0].min)+"\u00b0.")}catch(e){return out("Couldn't get the weather: "+e.message)}}
  case"remind":{const w=parseWhen(c.a,Date.now());if(!w.when||!w.rest)return out("When should I remind you? Try \u201cremind me to call mom in 10 minutes\u201d or \u201cat 5pm\u201d.");addRem(cap(w.rest),w.when.getTime());return out("Okay, I'll remind you to "+w.rest+" on "+fmtWhen(w.when)+". I'll alert you while JARVIS is running. Android can pause web apps, so use a calendar alarm for important ones.")}
  case"event":{const w=parseWhen(c.a,Date.now());if(!w.when||!w.rest)return out("When is it? Try \u201cschedule dentist tomorrow at 3pm\u201d.");EVTS.push({id:Date.now()+"",title:cap(w.rest),date:iso(w.when),time:w.timed?String(w.when.getHours()).padStart(2,"0")+":"+String(w.when.getMinutes()).padStart(2,"0"):""});saveE();return out("Added \u201c"+cap(w.rest)+"\u201d to your calendar on "+fmtWhen(w.when)+".")}
  case"translate":case"summarize":{const box=addMsg("\u2026","ai");try{const txt=await aiTool(c.k,c.k==="translate"?{to:c.a[1]}:{fmt:"short"},c.a[0],t=>box.textContent=t);$("vans").textContent=txt;if(ST.voice&&CURS==="voice")speak(txt,resumeWake)}catch(e){box.textContent=e.message;box.style.color="#ff8aa0"}return}
  case"call":return confirmAct("Open the dialer for "+c.a+"? You still have to press call.",()=>openTarget("the dialer",{web:"tel:"+c.a}));
  case"mail":return confirmAct("Start an email to "+c.a+"?",()=>openTarget("your email app",{web:"mailto:"+c.a}))}}
function ask(t,viaVoice){const s=t.trim();if(!s)return;
 if(PENDING){const p=PENDING;PENDING=null;if(/^(yes|yeah|confirm|ok|okay|do it|sure)$/i.test(s.replace(/[.!?]+$/,""))){addMsg(s,"me");return p.fn()}if(/^(no|cancel|stop|don't|dont)$/i.test(s.replace(/[.!?]+$/,""))){addMsg(s,"me");return out("Cancelled.")}}
 const c=parseCmd(s);if(c.k==="ai")return send(s,viaVoice);
 if(!viaVoice&&c.k!=="go")go("chat");if(c.k!=="go")addMsg(s,"me");runCmd(c)}
function handle(t){$("vtxt").textContent=t;ask(t,true)}
function rA(){$("alist").innerHTML=allApps().map(a=>`<div class="row"><span class="sp" data-open="${a.id}" style="cursor:pointer">${esc(a.name)}<small>${a.pkg?"Opens the app if installed, else the website":"Opens the website"}</small></span>${a.id.startsWith("c_")?`<button data-del="${a.id}" style="background:none;border:0;color:var(--mu);font-size:18px">\u2715</button>`:""}</div>`).join("")}
$("alist").onclick=e=>{const t=e.target.closest("[data-open],[data-del]");if(!t)return;if(t.dataset.del){CAPPS=CAPPS.filter(a=>a.id!==t.dataset.del);saveA();rA();return}const a=allApps().find(x=>x.id===t.dataset.open);if(a){go("chat");addMsg("Test: open "+a.name,"me");openTarget(a.name,a)}};
$("aadd").onclick=()=>{const n=$("an").value,l=$("al").value,p=$("ap").value,m=validApp(n,l,p);$("amsg").textContent=m;if(m)return;const web=/^https?:/i.test(l.trim());CAPPS.push({id:"c_"+Date.now(),name:n.trim(),al:[norm(n)],web:web?l.trim():"",link:web?"":l.trim(),pkg:p.trim()});saveA();rA();$("an").value=$("al").value=$("ap").value="";$("amsg").textContent="Added."};
function platInfo(){$("plat").textContent=(IS_ANDROID?"Android web app":"Not Android (desktop or other)")+" \u00b7 "+(Native?"native layer connected":"native layer not installed")+". Opens apps through links; cannot control the phone itself."}
$("mic").onclick=()=>{if(!SR){err("unsupported");return}blocked=false;$("vnote").textContent="";if(spk){stopSpeak();resumeWake();return}if(listening&&!recWake){stopRec();resumeWake();return}startRec(false)};
if(window.speechSynthesis)speechSynthesis.onvoiceschanged=()=>{checkVoices();apply()};
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="hidden"){stopRec();stopSpeak()}else resumeWake()});
document.querySelectorAll('[data-s="wake"]').forEach(el=>el.addEventListener("input",()=>{if(CURS==="voice"){blocked=false;ST.wake?startRec(true):stopRec()}}));
document.querySelector('[data-s="lang"]').addEventListener("input",checkVoices);
function rT(){rT0();DB.set("tasks",tasks)}
function rT0(){$("tlist").innerHTML=tasks.length?tasks.map((t,i)=>`<div class="row item ${t.d?"done":""}"><input type="checkbox" style="width:22px;height:22px;accent-color:var(--cy)" ${t.d?"checked":""} data-t="${i}"><span class="sp">${esc(t.x)}</span><button data-x="${i}" style="background:none;border:0;color:var(--mu);font-size:18px">✕</button></div>`).join(""):'<div class="row"><span class="muted">No tasks yet.</span></div>';stats()}
$("tadd").onclick=()=>{const v=$("tin").value.trim();if(!v)return;tasks.push({x:v,d:false});$("tin").value="";rT()};
$("tin").onkeydown=e=>{if(e.key==="Enter")$("tadd").click()};
$("tlist").onclick=e=>{const t=e.target.dataset;if(t.t!==undefined)tasks[t.t].d=e.target.checked;if(t.x!==undefined)tasks.splice(t.x,1);rT()};
function rN(){rN0();DB.set("notes",notes)}
function rN0(){$("nlist").innerHTML=notes.map((n,i)=>`<div class="box" style="padding:16px;margin-bottom:12px;line-height:1.5"><div>${esc(n)}</div><button data-d="${i}" class="muted" style="background:none;border:0;margin-top:8px;padding:0">Delete</button></div>`).join("");stats()}
$("nadd").onclick=()=>{const v=$("nin").value.trim();if(!v)return;notes.unshift(v);$("nin").value="";rN()};
$("nlist").onclick=e=>{if(e.target.dataset.d!==undefined){notes.splice(e.target.dataset.d,1);rN()}};
const DEF={name:"JARVIS",greet:"at your service",ac:"#22d3ee",fs:100,anim:true,lang:"en",voice:true,rate:1,wake:false,model:"gpt-4o-mini",temp:0.7,style:"balanced",hist:true,me:"",about:"",theme:"dark",voiceName:"",pitch:1,h24:false,chips:true,keep:0};
let ST={...DEF};try{Object.assign(ST,JSON.parse(localStorage.getItem("jv")||"{}"))}catch(e){}
function save(){try{localStorage.setItem("jv",JSON.stringify(ST))}catch(e){}}
function apply(){fillVoices();applyTheme();document.documentElement.style.setProperty("--cy",ST.ac);document.querySelector("main").style.zoom=ST.fs/100;document.body.classList.toggle("noanim",!ST.anim);document.querySelectorAll("[data-s]").forEach(el=>{const v=ST[el.dataset.s];if(el.type==="checkbox")el.checked=v;else if(el!==document.activeElement)el.value=v});$("fsv").textContent=ST.fs+"%";document.querySelector(".chips").style.display=ST.chips?"":"none";head();translateUI()}
document.querySelectorAll("[data-s]").forEach(el=>el.addEventListener("input",()=>{const k=el.dataset.s;ST[k]=el.type==="checkbox"?el.checked:el.type==="range"?+el.value:el.value;save();apply()}));
let cc=0;$("wipe").onclick=function(){if(!cc){cc=1;this.textContent="Tap again to confirm";setTimeout(()=>{cc=0;this.textContent="Delete all data"},4000);return}tasks.length=0;notes.length=0;CH=[];CUR=null;DB.clearAll();try{localStorage.removeItem("jvpin");localStorage.removeItem("jv");localStorage.removeItem("jvchats");localStorage.removeItem("jvcode");localStorage.removeItem("jvapps");["jvrem","jvevt","jvcity"].forEach(k=>localStorage.removeItem(k));REMS=[];EVTS=[];CAPPS=[];rA()}catch(e){}renderChat();ST={...DEF};apply();rT();rN();cc=0;this.textContent="Deleted ✓"};
let EVTS=[],REMS=[],SEARCH_ON=false,TMR=null;
function saveE(){DB.set("events",EVTS)}
function saveR(){DB.set("reminders",REMS)}
function addRem(text,at){REMS.push({id:Date.now()+"_"+Math.floor(Math.random()*1e4),text,at,done:false});saveR()}
const fmtWhen=d=>d.toLocaleString([],{...HF(),weekday:"short",month:"short",day:"numeric",hour:"numeric",minute:"2-digit"});
function toast(msg,btns){const t=$("toast"),d=document.createElement("div");d.className="ti";const m=document.createElement("div");m.textContent=msg;d.appendChild(m);const r=mkBtns(btns);if(r)d.appendChild(r);d.onclick=e=>{if(e.target.tagName!=="BUTTON")d.remove()};t.appendChild(d);setTimeout(()=>d.remove(),btns?15000:8000)}
function checkRem(){const n=Date.now();let ch=false;REMS.filter(r=>!r.done&&r.at<=n).forEach(r=>{r.done=true;ch=true;const late=n-r.at>120000;toast((late?"Missed reminder: ":"Reminder: ")+r.text);try{navigator.vibrate&&navigator.vibrate([200,100,200])}catch(e){}if(ST.voice&&!late)speak("Reminder: "+r.text);if(document.visibilityState!=="visible")notify("JARVIS",(late?"Missed reminder: ":"Reminder: ")+r.text)});if(ch)saveR()}
async function api(path){const r=await fetch(path,{headers:{"x-access-code":localStorage.getItem("jvcode")||""}});if(r.status===401){const c=prompt("Enter your access code");if(c)localStorage.setItem("jvcode",c);throw new Error("Access code needed. Try again.")}const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(r.status===404&&!j.error?"Can't reach the JARVIS server.":j.error||"Server error ("+r.status+")");return j}
async function aiTool(mode,opt,text,on){const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json","x-access-code":localStorage.getItem("jvcode")||""},body:JSON.stringify({mode,opt,messages:[{role:"user",content:text}],settings:{name:ST.name,lang:ST.lang,model:ST.model,temp:ST.temp,style:ST.style}})});
 if(r.status===401){const c=prompt("Enter your access code");if(c)localStorage.setItem("jvcode",c);throw new Error("Access code needed. Try again.")}
 if(!r.ok)throw new Error(r.status===404||r.status===405?"Can't reach the JARVIS server.":(await r.json().catch(()=>({}))).error||"Server error ("+r.status+")");
 const rd=r.body.getReader(),dec=new TextDecoder();let buf="",o="";for(;;){const{done,value}=await rd.read();if(done)break;buf+=dec.decode(value,{stream:true});let i;while((i=buf.indexOf("\n\n"))>=0){const ln=buf.slice(0,i).trim();buf=buf.slice(i+2);if(!ln.startsWith("data:"))continue;const d=ln.slice(5).trim();if(d==="[DONE]")continue;const j=JSON.parse(d);if(j.error)throw new Error(j.error);o+=j.t;on&&on(o)}}return o}
async function runAI(mode,opt,text,oid,aid){text=text.trim();if(!text)return;const o=$(oid);o.style.display="block";o.style.color="";o.textContent="\u2026";$(aid).innerHTML="";try{const r=await aiTool(mode,opt,text,t=>o.textContent=t);$(aid).appendChild(mkBtns([{label:"Copy",ghost:true,keep:true,fn:()=>navigator.clipboard&&navigator.clipboard.writeText(r).catch(()=>{})},{label:"Speak",ghost:true,keep:true,fn:()=>speak(r)}]))}catch(e){o.textContent=e.message;o.style.color="#ff8aa0"}}
function wHtml(d){return`<div class="box" style="padding:18px"><div class="muted">${esc(d.place)}</div><div style="font-family:var(--serif);font-size:54px">${Math.round(d.temp)}\u00b0C</div><div>${wmo(d.code)}</div><div class="muted" style="margin-top:6px">Feels ${Math.round(d.feels)}\u00b0 \u00b7 Humidity ${d.humidity}% \u00b7 Wind ${Math.round(d.wind)} km/h</div></div><div class="box list" style="margin-top:12px">${d.days.map(x=>`<div class="row"><span class="sp">${new Date(x.date+"T12:00").toLocaleDateString([],{weekday:"long"})}<small>${wmo(x.code)}</small></span><b>${Math.round(x.max)}\u00b0 / ${Math.round(x.min)}\u00b0</b></div>`).join("")}</div>`}
const XB='background:none;border:0;color:var(--mu);font-size:18px';
const TOOLS={
calc:{t:"Calculator",h:`<div class="box" style="padding:14px"><input class="f" id="cex" inputmode="none" autocomplete="off" placeholder="0" style="font-size:24px;text-align:right"><div id="cres" style="text-align:right;color:var(--cy);font-size:20px;min-height:30px;margin:8px 4px"></div><div id="ckeys" style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px"></div></div><div class="lbl">HISTORY</div><div class="box list" id="chist"></div>`,
 i(){const K=["C","\u232b","%","\u00f7","7","8","9","\u00d7","4","5","6","-","1","2","3","+","0",".","^","=","\u221a","(",")","\u03c0"],H=[];
  $("ckeys").innerHTML=K.map(k=>`<button class="btn sm ghost" style="margin:0;padding:14px 0;font-size:18px${k==="="?";background:var(--cy);color:#04141a":""}" data-k="${k}"${k==="\u232b"?' aria-label="Backspace"':""}>${k}</button>`).join("");
  const pv=()=>{try{$("cres").textContent=$("cex").value.trim()?"= "+fmt(calc($("cex").value)):""}catch(e){$("cres").textContent=""}};
  $("ckeys").onclick=e=>{const k=e.target.dataset.k;if(!k)return;const x=$("cex");if(k==="C")x.value="";else if(k==="\u232b")x.value=x.value.slice(0,-1);else if(k==="\u221a")x.value+="sqrt(";else if(k==="\u03c0")x.value+="pi";else if(k==="="){try{const r=calc(x.value);H.unshift(x.value+" = "+fmt(r));$("chist").innerHTML=H.slice(0,6).map(h=>`<div class="row">${esc(h)}</div>`).join("");x.value=String(r)}catch(er){$("cres").textContent=er.message;return}}else x.value+=k;pv()};
  $("cex").oninput=pv}},
unit:{t:"Unit converter",h:`<div class="box" style="padding:14px"><select id="ucat" style="max-width:none;width:100%;margin-bottom:10px"></select><input class="f" id="uv" type="number" inputmode="decimal" value="1" style="margin-bottom:10px"><div class="row" style="border:0;padding:0;gap:8px"><select id="uf" style="flex:1;max-width:none"></select><button class="btn sm ghost" id="usw" style="margin:0">\u21c4</button><select id="ut" style="flex:1;max-width:none"></select></div><div id="ur" style="font-family:var(--serif);font-size:30px;margin-top:16px"></div></div>`,
 i(){$("ucat").innerHTML=Object.keys(UNITS).map(c=>`<option>${c}</option>`).join("");
  const calcU=()=>{const v=parseFloat($("uv").value);$("ur").textContent=isNaN(v)?"":fmt(convert(v,$("uf").value,$("ut").value,$("ucat").value))+" "+$("ut").value};
  const fill=()=>{const u=UNITS[$("ucat").value],ks=u?Object.keys(u):["C","F","K"];$("uf").innerHTML=$("ut").innerHTML=ks.map(k=>`<option>${k}</option>`).join("");$("ut").selectedIndex=1;calcU()};
  $("ucat").onchange=fill;["uv","uf","ut"].forEach(i=>{$(i).oninput=$(i).onchange=calcU});$("usw").onclick=()=>{const a=$("uf").value;$("uf").value=$("ut").value;$("ut").value=a;calcU()};fill()}},
time:{t:"Time & date",h:`<div class="box" style="padding:20px;text-align:center"><div id="tc" style="font-family:var(--serif);font-size:54px"></div><div id="td" class="muted"></div><div id="tz" class="muted" style="font-size:12.5px;margin-top:4px"></div></div><div class="lbl">WORLD CLOCKS</div><div class="box list" id="tw"></div>`,
 i(){const Z=[["Dhaka","Asia/Dhaka"],["London","Europe/London"],["New York","America/New_York"],["Dubai","Asia/Dubai"],["Tokyo","Asia/Tokyo"],["Sydney","Australia/Sydney"]];
  const tick=()=>{const n=new Date();$("tc").textContent=n.toLocaleTimeString([],{...HF(),hour:"2-digit",minute:"2-digit",second:"2-digit"});$("td").textContent=n.toLocaleDateString([],{weekday:"long",year:"numeric",month:"long",day:"numeric"});$("tz").textContent=Intl.DateTimeFormat().resolvedOptions().timeZone;$("tw").innerHTML=Z.map(z=>`<div class="row"><span class="sp">${z[0]}</span><b>${n.toLocaleTimeString([],{...HF(),hour:"2-digit",minute:"2-digit",timeZone:z[1]})}</b></div>`).join("")};tick();TMR=setInterval(tick,1000)}},
weather:{t:"Weather",h:`<div class="comp"><input id="wc" placeholder="City"><button class="go" id="wgo">\u2192</button></div><button class="btn sm ghost" id="wloc" style="margin-top:10px">Use my location</button><div id="wr" style="margin-top:14px"></div>`,
 i(){$("wc").value=localStorage.getItem("jvcity")||"";
  const show=async q=>{$("wr").innerHTML='<p class="muted">Loading\u2026</p>';try{$("wr").innerHTML=wHtml(await api("/api/weather?"+q))}catch(e){$("wr").innerHTML=`<p style="color:#ff8aa0">${esc(e.message)}</p>`}};
  $("wgo").onclick=()=>{const c=$("wc").value.trim();if(!c)return;try{localStorage.setItem("jvcity",c)}catch(e){}show("city="+enc(c))};$("wc").onkeydown=e=>{if(e.key==="Enter")$("wgo").click()};
  $("wloc").onclick=()=>{if(!navigator.geolocation){$("wr").innerHTML="<p class='muted'>Location isn't available here.</p>";return}navigator.geolocation.getCurrentPosition(p=>show("lat="+p.coords.latitude.toFixed(3)+"&lon="+p.coords.longitude.toFixed(3)),()=>{$("wr").innerHTML="<p class='muted'>Location permission was denied. Type a city instead.</p>"},{timeout:10000})};
  if($("wc").value)$("wgo").click()}},
rem:{t:"Reminders",h:`<textarea class="f" id="rt" rows="2" placeholder="Remind me to\u2026"></textarea><input class="f" id="rw" type="datetime-local" style="margin:8px 0"><button class="btn" id="radd">Add reminder</button><p class="muted" id="rmsg" style="margin:8px 0"></p><div class="box list" id="rl"></div><p class="muted" style="font-size:12.5px;margin-top:12px">Reminders alert you (sound, vibration, voice and a notification if allowed) while JARVIS is running. Android can pause web apps in the background, so for important ones also add a calendar alarm.</p>`,
 i(){$("rw").value=new Date(Date.now()-new Date().getTimezoneOffset()*6e4+36e5).toISOString().slice(0,16);
  const rR=()=>{const l=[...REMS].sort((a,b)=>a.at-b.at);$("rl").innerHTML=l.length?l.map(r=>`<div class="row"><span class="sp" style="${r.done?"opacity:.5":""}">${esc(r.text)}<small>${fmtWhen(new Date(r.at))}${r.done?" \u00b7 done":""}</small></span><button data-x="${r.id}" style="${XB}">\u2715</button></div>`).join(""):'<div class="row"><span class="muted">No reminders.</span></div>'};
  $("radd").onclick=()=>{const t=$("rt").value.trim(),at=new Date($("rw").value).getTime();if(!t){$("rmsg").textContent="Write what to remind you about.";return}if(!(at>Date.now())){$("rmsg").textContent="Pick a time in the future.";return}addRem(t,at);$("rt").value="";$("rmsg").textContent="Added.";rR()};
  $("rl").onclick=e=>{const id=e.target.dataset.x;if(id){REMS=REMS.filter(r=>r.id!==id);saveR();rR()}};rR()}},
cal:{t:"Calendar",h:`<div class="row" style="border:0;justify-content:space-between"><button class="btn sm ghost" id="cp" style="margin:0">\u2039</button><b id="cm" style="font-family:var(--serif);font-size:22px"></b><button class="btn sm ghost" id="cn" style="margin:0">\u203a</button></div><div class="box" style="padding:10px"><div id="cg" style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;text-align:center"></div></div><div class="lbl" id="cdl"></div><div class="box list" id="cel"></div><div class="row" style="border:0;gap:8px;margin-top:10px"><input class="f" id="cet" placeholder="New event"><input class="f" id="cetm" type="time" style="width:120px"><button class="go" id="cea">+</button></div>`,
 i(){const n0=new Date();let y=n0.getFullYear(),m=n0.getMonth(),sel=iso(n0);
  const list=()=>{$("cdl").textContent=new Date(sel+"T12:00").toLocaleDateString([],{weekday:"long",month:"long",day:"numeric"}).toUpperCase();const ev=EVTS.filter(e=>e.date===sel).sort((a,b)=>(a.time||"").localeCompare(b.time||"")),rm=REMS.filter(r=>!r.done&&iso(new Date(r.at))===sel);$("cel").innerHTML=ev.length+rm.length?ev.map(e=>`<div class="row"><span class="sp">${esc(e.title)}<small>${e.time||"All day"}</small></span><button data-x="${e.id}" style="${XB}">\u2715</button></div>`).join("")+rm.map(r=>`<div class="row"><span class="sp">\u23f0 ${esc(r.text)}<small>${new Date(r.at).toLocaleTimeString([],{...HF(),hour:"2-digit",minute:"2-digit"})}</small></span></div>`).join(""):'<div class="row"><span class="muted">Nothing planned.</span></div>'};
  const render=()=>{$("cm").textContent=new Date(y,m,1).toLocaleDateString([],{month:"long",year:"numeric"});const f=new Date(y,m,1).getDay(),n=new Date(y,m+1,0).getDate(),today=iso(new Date());let h="SMTWTFS".split("").map(c=>`<div class="muted" style="font-size:12px">${c}</div>`).join("");for(let k=0;k<f;k++)h+="<div></div>";for(let k=1;k<=n;k++){const di=iso(new Date(y,m,k)),has=EVTS.some(e=>e.date===di)||REMS.some(r=>!r.done&&iso(new Date(r.at))===di);h+=`<button data-d="${di}" style="min-height:42px;border-radius:12px;border:1px solid ${di===sel?"var(--cy)":"transparent"};background:${di===today?"var(--s2)":"none"};color:var(--tx);font-size:15px;position:relative">${k}${has?'<i style="position:absolute;bottom:5px;left:50%;width:5px;height:5px;margin-left:-2.5px;border-radius:50%;background:var(--cy)"></i>':""}</button>`}$("cg").innerHTML=h;list()};
  $("cp").onclick=()=>{m--;if(m<0){m=11;y--}render()};$("cn").onclick=()=>{m++;if(m>11){m=0;y++}render()};
  $("cg").onclick=e=>{const b=e.target.closest("[data-d]");if(b){sel=b.dataset.d;render()}};
  $("cel").onclick=e=>{const id=e.target.dataset.x;if(id){EVTS=EVTS.filter(x=>x.id!==id);saveE();render()}};
  $("cea").onclick=()=>{const t=$("cet").value.trim();if(!t)return;EVTS.push({id:Date.now()+"",title:t,date:sel,time:$("cetm").value});saveE();$("cet").value="";render()};render()}},
trans:{t:"Translate",h:`<textarea class="f" id="tx" rows="5" placeholder="Text to translate"></textarea><div class="row" style="border:0;padding:10px 0"><span class="muted">To</span><select id="tl" style="max-width:none;flex:1"></select><button class="btn" id="tg">Translate</button></div><div class="box" id="to" style="padding:16px;min-height:80px;white-space:pre-wrap;display:none"></div><div id="tact"></div>`,
 i(){$("tl").innerHTML=LANGS.map(l=>`<option>${l}</option>`).join("");$("tg").onclick=()=>runAI("translate",{to:$("tl").value},$("tx").value,"to","tact")}},
sum:{t:"Summarizer",h:`<textarea class="f" id="sx" rows="7" placeholder="Paste text to summarize"></textarea><div class="row" style="border:0;padding:10px 0"><select id="sf" style="max-width:none;flex:1"><option value="short">Short</option><option value="bullets">Bullet points</option><option value="detailed">Detailed</option></select><button class="btn" id="sg">Summarize</button></div><div class="box" id="so" style="padding:16px;min-height:80px;white-space:pre-wrap;display:none"></div><div id="sact"></div>`,
 i(){$("sg").onclick=()=>runAI("summarize",{fmt:$("sf").value},$("sx").value,"so","sact")}},
search:{t:"Web search",h:`<div class="comp"><input id="sq" placeholder="Search the web"><button class="go" id="sgo2">\u2192</button></div><div class="chips" style="justify-content:flex-start" id="seng"></div><div id="sres"></div><p class="muted" id="snote" style="font-size:12.5px;margin-top:10px"></p>`,
 i(){const E=[["Google","https://www.google.com/search?q="],["DuckDuckGo","https://duckduckgo.com/?q="],["YouTube","https://www.youtube.com/results?search_query="],["Wikipedia","https://en.wikipedia.org/w/index.php?search="]];
  $("seng").innerHTML=E.map((e,i)=>`<button class="chip" data-e="${i}">${e[0]}</button>`).join("");
  $("seng").onclick=e=>{const i=e.target.dataset.e,q=$("sq").value.trim();if(i===undefined||!q)return;openTarget(E[i][0],{web:E[i][1]+enc(q),pkg:E[i][0]==="YouTube"?"com.google.android.youtube":undefined})};
  $("snote").textContent=SEARCH_ON?"Results appear here. Tap one to open it.":"In-app results need a Brave Search key on the server (BRAVE_API_KEY). Until then, pick an engine above.";
  const run=async()=>{const q=$("sq").value.trim();if(!q)return;if(!SEARCH_ON){$("seng").querySelector("[data-e]").click();return}$("sres").innerHTML='<p class="muted">Searching\u2026</p>';
   try{const d=await api("/api/search?q="+enc(q));$("sres").innerHTML=d.results.length?`<div class="box list">${d.results.map((r,i)=>`<div class="row" data-r="${i}" style="display:block;cursor:pointer"><b>${esc(r.title)}</b><small>${esc(r.url)}</small><div class="muted" style="font-size:13.5px">${esc(r.desc)}</div></div>`).join("")}</div>`:'<p class="muted">No results.</p>';$("sres").onclick=e=>{const r=e.target.closest("[data-r]");if(r)openTarget("the page",{web:d.results[r.dataset.r].url})}}catch(e){$("sres").innerHTML=`<p style="color:#ff8aa0">${esc(e.message)}</p>`}};
  $("sgo2").onclick=run;$("sq").onkeydown=e=>{if(e.key==="Enter")run()}}},
browser:{t:"Browser",h:`<div class="comp"><input id="bu" placeholder="Website or address"><button class="go" id="bgo">\u2192</button></div><div class="lbl">QUICK LINKS</div><div class="box list" id="bl"></div>`,
 i(){const Q=[["Google","https://www.google.com/"],["YouTube","https://www.youtube.com/"],["Wikipedia","https://www.wikipedia.org/"],["Gmail","https://mail.google.com/"],["GitHub","https://github.com/"],["BBC News","https://www.bbc.com/news"]];
  $("bl").innerHTML=Q.map((q,i)=>`<button class="row" data-bq="${i}"><span class="sp">${q[0]}<small>${q[1]}</small></span><span class="ch">\u203a</span></button>`).join("");
  $("bl").onclick=e=>{const b=e.target.closest("[data-bq]");if(b)openTarget(Q[b.dataset.bq][0],{web:Q[b.dataset.bq][1]})};
  const run=()=>{const v=$("bu").value.trim();if(!v)return;if(isDomain(v))openTarget(v,{web:siteUrl(v)});else openTarget("Google search",{web:"https://www.google.com/search?q="+enc(v)})};$("bgo").onclick=run;$("bu").onkeydown=e=>{if(e.key==="Enter")run()}}}};
function openTool(id){clearInterval(TMR);const T=TOOLS[id];if(!T)return;$("ttl").textContent=T.t;$("tbody").innerHTML=T.h;go("tool");T.i()}
document.addEventListener("click",e=>{const b=e.target.closest("[data-tool]");if(b)openTool(b.dataset.tool)});
try{fetch("/api/health").then(r=>r.json()).then(j=>{SEARCH_ON=!!j.search}).catch(()=>{})}catch(e){}
setInterval(checkRem,10000);

const HF=()=>ST.h24?{hour12:false}:{};
const MQ=window.matchMedia?matchMedia("(prefers-color-scheme: light)"):null;
function applyTheme(){const t=ST.theme==="auto"?(MQ&&MQ.matches?"light":"dark"):ST.theme;document.documentElement.dataset.theme=t;const m=document.querySelector('meta[name=theme-color]');if(m)m.content=t==="light"?"#f5f7fb":"#0a0e15"}
if(MQ&&MQ.addEventListener)MQ.addEventListener("change",()=>{if(ST.theme==="auto")applyTheme()});
//<i18n>
const BN={"Home":"হোম","Chat":"চ্যাট","Voice":"ভয়েস","Tools":"টুলস","Settings":"সেটিংস","Tasks":"কাজ","Notes":"নোট","Online":"অনলাইন","History":"ইতিহাস","+ New chat":"+ নতুন চ্যাট","Open tasks":"চলমান কাজ","Tap the mic and speak.":"মাইক ট্যাপ করে বলুন।","PROFILE":"প্রোফাইল","APPEARANCE":"চেহারা","LANGUAGE & VOICE":"ভাষা ও ভয়েস","PREFERENCES":"পছন্দ","PRIVACY & DATA":"গোপনীয়তা ও ডেটা","DEVICE & APPS":"ডিভাইস ও অ্যাপ","AI":"এআই","Assistant name":"সহকারীর নাম","Greeting":"শুভেচ্ছা বার্তা","Your name":"আপনার নাম","About you":"আপনার সম্পর্কে","Theme":"থিম","Accent color":"অ্যাকসেন্ট রং","Text size":"লেখার আকার","Animations":"অ্যানিমেশন","Language":"ভাষা","Voice replies":"কণ্ঠে উত্তর","Speaking speed":"কথা বলার গতি","Pitch":"সুর","Wake word":"ওয়েক ওয়ার্ড","Model":"মডেল","Creativity":"সৃজনশীলতা","Reply style":"উত্তরের ধরন","24-hour time":"২৪-ঘণ্টার সময়","Show suggestions":"পরামর্শ দেখান","Save chat history":"চ্যাট ইতিহাস সংরক্ষণ","App lock (PIN)":"অ্যাপ লক (পিন)","Export my data":"আমার ডেটা এক্সপোর্ট","Clear chat history":"চ্যাট ইতিহাস মুছুন","Delete all data":"সব ডেটা মুছুন","Calculator":"ক্যালকুলেটর","Unit converter":"ইউনিট কনভার্টার","Time & date":"সময় ও তারিখ","Weather":"আবহাওয়া","Reminders":"রিমাইন্ডার","Calendar":"ক্যালেন্ডার","Translate":"অনুবাদ","Summarizer":"সারসংক্ষেপ","Web search":"ওয়েব সার্চ","Browser":"ব্রাউজার","Apps & links":"অ্যাপ ও লিংক","Speak replies":"উত্তর শুনুন"};
const BNP={"Ask JARVIS anything…":"JARVIS-কে যেকোনো কিছু জিজ্ঞাসা করুন…"};
//</i18n>
function translateUI(){const bn=ST.lang==="bn",w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode()){const raw=n.__o!==undefined?n.__o:n.nodeValue,k=raw.trim();if(n.__o!==undefined||BN[k]!==undefined){if(n.__o===undefined)n.__o=raw;n.nodeValue=bn&&BN[k]?raw.replace(k,()=>BN[k]):raw}}
 document.querySelectorAll("input[placeholder]").forEach(e=>{const o=e.dataset.po||e.getAttribute("placeholder");if(BNP[o]!==undefined){e.dataset.po=o;e.placeholder=bn?BNP[o]:o}})}
function pickV(l){return pickVoice(l)}
function chooseVoice(l){const vs=window.speechSynthesis?speechSynthesis.getVoices():[],p=l==="bn"?"bn":"en",c=ST.voiceName&&vs.find(v=>v.name===ST.voiceName&&v.lang.toLowerCase().startsWith(p));return c||pickVoice(l)}
function fillVoices(){const el=document.querySelector('[data-s="voiceName"]');if(!el)return;const p=ST.lang==="bn"?"bn":"en",vs=window.speechSynthesis?speechSynthesis.getVoices().filter(v=>v.lang.toLowerCase().startsWith(p)):[],sig=vs.map(v=>v.name).join("|")+p;if(el.dataset.sig===sig)return;el.dataset.sig=sig;el.innerHTML='<option value="">Automatic</option>'+vs.map(v=>`<option value="${esc(v.name).replace(/"/g,"&quot;")}">${esc(v.name)}</option>`).join("")}
$("vprev").onclick=()=>speak(ST.lang==="bn"?"হ্যালো, আমি "+ST.name+"। আমি আপনাকে কীভাবে সাহায্য করতে পারি?":"Hello, I'm "+ST.name+". How can I help?");
function twoTap(b,label,fn){let c=0,t;b.onclick=()=>{if(!c){c=1;b.textContent="Tap again to confirm";t=setTimeout(()=>{c=0;b.textContent=label},4000);return}clearTimeout(t);c=0;b.textContent=label;fn()}}
twoTap($("clrc"),"Clear chat history",()=>{CH=[];CUR=null;DB.clearChats();cur();renderChat();rH();storInfo();$("clrc").textContent="Cleared ✓"});
$("expd").onclick=()=>{const d={exported:new Date().toISOString(),settings:ST,tasks,notes,chats:CH.filter(c=>c.msgs.length),reminders:REMS,events:EVTS};for(const k of Object.keys(localStorage)){if(k.startsWith("jv")&&!["jv","jvcode","jvpin"].includes(k)){try{d[k]=JSON.parse(localStorage.getItem(k))}catch(e){}}}const b=new Blob([JSON.stringify(d,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="jarvis-data.json";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),5000)};
let lockRes=null,lockAttempts=0,lockUntil=0,locking=false,hiddenAt=0;
function pinAsk(title,cancel,forgot,msg){return new Promise(res=>{lockRes=res;$("lt").textContent=title;$("lpin").value="";$("lmsg").textContent=msg||"";$("lcan").style.display=cancel?"":"none";$("lfor").style.display=forgot?"":"none";$("lock").style.display="flex";setTimeout(()=>$("lpin").focus(),50)})}
function pinClose(v){$("lock").style.display="none";const r=lockRes;lockRes=null;r&&r(v)}
$("lok").onclick=()=>pinClose($("lpin").value);$("lcan").onclick=()=>pinClose(null);$("lfor").onclick=()=>pinClose("__forgot__");$("lpin").onkeydown=e=>{if(e.key==="Enter")$("lok").click()};
async function hashPin(p,salt){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(salt+":"+p));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")}
function pinStored(){try{return localStorage.getItem("jvpin")}catch(e){return null}}
function lockStatus(m){$("lockst").textContent=m||(pinStored()?"On. Stops casual access; data is not encrypted":"Off")}
$("lockbtn").onclick=async()=>{
 if(!(window.crypto&&crypto.subtle))return lockStatus("App lock needs a secure https connection.");
 const st=pinStored();
 if(st){const[salt,h]=st.split(":"),p=await pinAsk("Enter your PIN to turn off app lock",true,false);if(p===null)return;if(await hashPin(p,salt)===h){try{localStorage.removeItem("jvpin")}catch(e){}lockStatus()}else lockStatus("Wrong PIN. App lock is still on.");return}
 const p1=await pinAsk("Choose a PIN (4 to 8 digits)",true,false);if(p1===null)return;if(!/^\d{4,8}$/.test(p1))return lockStatus("Use 4 to 8 digits.");
 const p2=await pinAsk("Repeat the PIN",true,false);if(p2!==p1)return lockStatus(p2===null?"Cancelled.":"The PINs didn't match.");
 const salt=[...crypto.getRandomValues(new Uint8Array(8))].map(x=>x.toString(16).padStart(2,"0")).join("");
 try{localStorage.setItem("jvpin",salt+":"+await hashPin(p1,salt))}catch(e){}lockStatus()};
async function requireUnlock(){const st=pinStored();if(!st||locking||!(window.crypto&&crypto.subtle))return;locking=true;stopRec();stopSpeak();const[salt,h]=st.split(":");let msg="";
 for(;;){const p=await pinAsk("Enter PIN",false,true,msg);msg="";
  if(p==="__forgot__"){if(confirm("Erase ALL JARVIS data on this device and remove the PIN?")){DB.clearAll().then(()=>{try{localStorage.clear()}catch(e){}location.reload()});return}continue}
  if(Date.now()<lockUntil){msg="Too many tries. Wait "+Math.ceil((lockUntil-Date.now())/1000)+" seconds.";continue}
  if(await hashPin(p||"",salt)===h){lockAttempts=0;break}
  if(++lockAttempts>=5){lockAttempts=0;lockUntil=Date.now()+30000;msg="Too many tries. Wait 30 seconds."}else msg="Wrong PIN."}
 locking=false}
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="hidden")hiddenAt=Date.now();else if(pinStored()&&Date.now()-hiddenAt>30000)requireUnlock()});
function pruneChats(){if(!+ST.keep)return;const lim=Date.now()-ST.keep*864e5,n=CH.length;CH=CH.filter(c=>(c.upd||c.id)>=lim);if(CH.length!==n)DB.syncChats(CH.filter(c=>c.msgs.length))}
async function loadData(){await DB.open();
 if(await DB.get("migrated",0)!==1){try{const lc=JSON.parse(localStorage.getItem("jvchats")||"null"),lr=JSON.parse(localStorage.getItem("jvrem")||"null"),le=JSON.parse(localStorage.getItem("jvevt")||"null");
  if(Array.isArray(lc))DB.syncChats(lc);if(Array.isArray(lr))DB.set("reminders",lr);if(Array.isArray(le))DB.set("events",le);await DB.set("migrated",1);await DB.flush();
  if(!DB.failed)["jvchats","jvrem","jvevt"].forEach(k=>localStorage.removeItem(k))}catch(e){}}
 CH=(await DB.chats()).filter(c=>c&&Array.isArray(c.msgs)).sort((a,b)=>(b.upd||b.id)-(a.upd||a.id));DB.rememberChats(CH);
 const g=async k=>{const v=await DB.get(k,[]);DB.remember(k,v);return Array.isArray(v)?v:[]};
 tasks.push(...await g("tasks"));notes.push(...await g("notes"));REMS=await g("reminders");EVTS=await g("events");pruneChats()}
function storInfo(){$("storinfo").textContent=CH.filter(c=>c.msgs.length).length+" chats · "+tasks.length+" tasks · "+notes.length+" notes · "+REMS.length+" reminders · "+EVTS.length+" events"+(DB.mode==="indexeddb"?"":" (basic storage mode)")}
async function storUse(){try{const sg=navigator.storage;$("storuse").textContent=sg&&sg.estimate?await sg.estimate().then(e=>fmtBytes(e.usage||0)+" of "+fmtBytes(e.quota||0)):"Not available";const p=sg&&sg.persisted?await sg.persisted():false;$("storps").textContent=p?"On: the browser won't clear your data automatically":"Off: the browser may clear data if the phone runs low on space"}catch(e){}}
$("storp").onclick=async()=>{const sg=navigator.storage;const ok=sg&&sg.persist?await sg.persist():false;await storUse();if(!ok)$("storps").textContent="The browser declined. It usually accepts once the app is installed."};
twoTap($("dchats"),"Delete chats",()=>{CH=[];CUR=null;DB.clearChats();cur();renderChat();rH();storInfo()});
twoTap($("dtn"),"Delete tasks & notes",()=>{tasks.length=0;notes.length=0;rT();rN();storInfo()});
twoTap($("drc"),"Delete reminders & calendar",()=>{REMS=[];EVTS=[];saveR();saveE();storInfo()});
apply();lockStatus();requireUnlock();
loadData().then(()=>{go("home");rT();rN();renderChat();checkVoices();rA();platInfo();checkRem();storInfo();handleLaunchParams()}).catch(()=>{go("home");renderChat()});


// ---- PWA: install, offline, updates, notifications ----
const APP_VER="0.9.0";let DEFERRED=null,SWREG=null;
const isStandalone=()=>(window.matchMedia&&matchMedia("(display-mode: standalone)").matches)||navigator.standalone===true;
function notStatus(){const el=$("notst");if(!el)return;el.textContent=!("Notification" in window)?"Not supported in this browser":Notification.permission==="granted"?"On: reminders can show notifications":Notification.permission==="denied"?"Blocked: allow it in the browser's site settings":"Off: tap to allow"}
function pwaStatus(){const t=isStandalone()?"Installed: running as an app":DEFERRED?"Ready: tap to install":"Use Chrome's menu > Install app (needs an https address)";$("instst").textContent=t;$("abinst").textContent=t;notStatus()}
async function abStatus(){$("abver").textContent="Version "+APP_VER;const c=navigator.serviceWorker&&navigator.serviceWorker.controller;$("aboff").textContent=c?"Ready: the app opens without internet":"Not active yet (needs https, then reload once)";try{const ks=await caches.keys(),k=ks.find(x=>x.startsWith("jarvis-shell-"));if(k)$("abver").textContent="Version "+APP_VER+" ("+k.slice(13)+")"}catch(e){}}
function showBanner(){try{if(DEFERRED&&!isStandalone()&&!localStorage.getItem("jvib"))$("ibanner").style.display="block"}catch(e){}}
async function doInstall(){if(isStandalone())return;if(!DEFERRED){toast("Open Chrome's menu and choose “Install app” or “Add to Home screen”. This needs an https address.");return}DEFERRED.prompt();try{await DEFERRED.userChoice}catch(e){}DEFERRED=null;$("ibanner").style.display="none";pwaStatus()}
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();DEFERRED=e;pwaStatus();showBanner()});
window.addEventListener("appinstalled",()=>{DEFERRED=null;$("ibanner").style.display="none";toast("JARVIS is installed.");pwaStatus()});
$("instbtn").onclick=doInstall;$("ibyes").onclick=doInstall;$("ibno").onclick=()=>{try{localStorage.setItem("jvib","1")}catch(e){}$("ibanner").style.display="none"};
$("notbtn").onclick=async()=>{if(!("Notification" in window)){toast("This browser doesn't support notifications.");return}if(Notification.permission==="default"){try{await Notification.requestPermission()}catch(e){}}notStatus();if(Notification.permission==="granted")notify("JARVIS","Notifications are on.")};
async function notify(title,body){try{if(!("Notification" in window)||Notification.permission!=="granted")return false;const reg=navigator.serviceWorker&&await navigator.serviceWorker.getRegistration();if(reg){await reg.showNotification(title,{body,icon:"/icons/icon-192.png",badge:"/icons/favicon-32.png",tag:"jarvis-reminder",data:{url:"/?go=tools"},vibrate:[200,100,200]});return true}new Notification(title,{body});return true}catch(e){return false}}
function netState(){const on=navigator.onLine,d=document.querySelector("header .dot");$("offbar").style.display=on?"none":"block";if(d){d.style.background=on?"":"#6b7280";d.style.boxShadow=on?"":"none"}}
window.addEventListener("online",netState);window.addEventListener("offline",netState);netState();
$("abupd").onclick=async()=>{const el=$("abupds");if(!SWREG){el.textContent="Updates work once the app runs over https";return}el.textContent="Checking…";try{await SWREG.update();el.textContent="You have the latest version (or it is updating now)"}catch(e){el.textContent=navigator.onLine?"Couldn't check":"You're offline"}};
function handleLaunchParams(){try{const q=new URLSearchParams(location.search),g=q.get("go"),el=g&&document.getElementById(g),ok=!!(el&&el.classList.contains("screen")),sh=[q.get("title"),q.get("text"),q.get("url")].filter(Boolean).join(" ").slice(0,2000);if(ok)go(g);else if(sh){go("chat");$("cin").value=sh}if(g||sh||q.has("text"))history.replaceState(null,"",location.pathname)}catch(e){}}
if("serviceWorker" in navigator&&(location.protocol==="https:"||/^(localhost|127\.0\.0\.1)$/.test(location.hostname))){const had=!!navigator.serviceWorker.controller;
 addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").then(reg=>{SWREG=reg;reg.addEventListener("updatefound",()=>{const w=reg.installing;if(w)w.addEventListener("statechange",()=>{if(w.state==="activated"&&had)toast("JARVIS was updated.",[{label:"Reload",fn:()=>location.reload()}])})});abStatus()}).catch(()=>{}));
 navigator.serviceWorker.addEventListener("controllerchange",abStatus)}
pwaStatus();abStatus();document.addEventListener("click",e=>{if(e.target.closest('[data-go="about"]'))abStatus()});

// ---- accessibility: names for icon-only controls ----
const A11Y={"↑":"Send","+":"Add","✕":"Delete item","⇄":"Swap units","→":"Go","‹":"Previous","›":"Next","⬇":"Download","🎤":"Microphone"},ACC={"#22d3ee":"Cyan","#60a5fa":"Blue","#a78bfa":"Violet","#34d399":"Green"};
function a11y(){document.querySelectorAll("button").forEach(b=>{if(b.hasAttribute("aria-label"))return;const t=b.textContent.trim();if(A11Y[t])b.setAttribute("aria-label",A11Y[t]);else if(!t&&b.dataset.ac)b.setAttribute("aria-label",(ACC[b.dataset.ac]||"Accent")+" accent color")});
 document.querySelectorAll("input,textarea,select").forEach(e=>{if(e.hasAttribute("aria-label")||(e.id&&document.querySelector('label[for="'+e.id+'"]')))return;const row=e.closest(".row"),src=row&&(row.querySelector(".sp")||row),n=e.placeholder||(src&&src.firstChild&&src.firstChild.textContent.trim())||e.id;if(n)e.setAttribute("aria-label",n)});
 document.documentElement.lang=ST.lang==="bn"?"bn":"en"}
let A11T=0;new MutationObserver(()=>{clearTimeout(A11T);A11T=setTimeout(a11y,50)}).observe(document.body,{childList:true,subtree:true});a11y();
