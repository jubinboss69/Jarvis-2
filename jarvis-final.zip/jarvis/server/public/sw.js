// JARVIS service worker: offline app shell, never caches API calls or user data.
const CACHE = "jarvis-shell-v1";
const SHELL = ["/", "/app.js", "/offline.html", "/manifest.webmanifest", "/icons/icon-192.png", "/icons/icon-512.png", "/icons/apple-touch-icon.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
const offlineJson = () => new Response(JSON.stringify({ error: "You're offline. This needs an internet connection." }), { status: 503, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
async function networkFirst(req, key, ms = 4000) {
  const c = await caches.open(CACHE), net = fetch(req);
  try {
    const r = await Promise.race([net, new Promise((_, no) => setTimeout(() => no(new Error("slow")), ms))]);
    if (r && r.ok) c.put(key || req, r.clone());
    return r;
  } catch (e) {
    const hit = await c.match(key || req, { ignoreSearch: true });
    return hit || net;
  }
}
async function cacheFirst(req) {
  const hit = await caches.match(req); if (hit) return hit;
  const r = await fetch(req); if (r.ok) caches.open(CACHE).then(c => c.put(req, r.clone())); return r;
}
self.addEventListener("fetch", e => {
  const req = e.request, u = new URL(req.url);
  if (req.method !== "GET" || u.origin !== location.origin) return;
  if (u.pathname.startsWith("/api/")) { e.respondWith(fetch(req).catch(offlineJson)); return; }
  if (req.mode === "navigate") {
    if (u.pathname === "/" || u.pathname === "/index.html") e.respondWith(networkFirst(req, "/"));
    else e.respondWith(fetch(req).catch(() => caches.match("/offline.html")));
    return;
  }
  e.respondWith(u.pathname === "/app.js" ? networkFirst(req) : cacheFirst(req));
});
self.addEventListener("notificationclick", e => {
  e.notification.close(); const url = (e.notification.data && e.notification.data.url) || "/";
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(cs => {
    for (const c of cs) if ("focus" in c) { if (c.navigate) c.navigate(url).catch(() => {}); return c.focus(); }
    return self.clients.openWindow(url);
  }));
});
