# JARVIS security notes

**Secrets.** The OpenAI key (and optional Brave key) live only in server environment variables. They are never sent to the browser, never returned by any route, and upstream error text is replaced with a short message. Set them in your host's settings, never in files you commit (`.env` is git-ignored).

**Access.** Set a long `ACCESS_CODE` (12+ characters). It is compared in constant time. After `AUTH_FAILS` wrong codes (default 10) that visitor is locked out for 10 minutes. Behind Render/Railway set `TRUST_PROXY=1` so limits apply per visitor, not to the whole proxy.

**Browser protection.** Strict Content-Security-Policy (scripts only from the app itself, no inline scripts), no framing, no plugins, mic/location limited to the app, HSTS behind https, no caching of API replies. Cross-origin POST requests are refused. All text you or the AI produce is shown as plain text, never as HTML.

**Input checks.** Message, text and field lengths are capped, models and languages use allow-lists, request bodies are capped at 200 KB, and requests time out.

**Your data.** Chats, tasks, notes, reminders and events are stored in IndexedDB on this device only (a localStorage fallback is used if IndexedDB is blocked). The server stores nothing about you. Settings > Storage shows what is saved and lets you delete each kind; Settings > Privacy has auto-delete, export, and Delete all data.

**Known limits.** Data on the device is not encrypted. The PIN lock only keeps casual users out. Anyone who can unlock your phone and browser profile can read the data. Usage limits are kept in server memory and reset on restart.
