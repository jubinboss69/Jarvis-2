// Optional real-browser PWA test (needs playwright + chromium)
import { server } from "../src/index.js";
let pw; try { pw = await import("playwright"); } catch { pw = await import("/opt/npm-tools/node_modules/playwright/index.mjs"); }
const { chromium } = pw.chromium ? pw : pw.default;
let fail = 0; const ok = (n, c) => { console.log((c ? "PASS " : "FAIL ") + n); if (!c) fail++; };
await new Promise(r => server.listen(4700, r)); const U = "http://localhost:4700/";
const browser = await chromium.launch({ channel: "chromium" }); const errors = [];
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, permissions: ["notifications"] });
const page = await ctx.newPage();
page.on("pageerror", e => errors.push(String(e))); page.on("console", m => { if (m.type() === "error" && !/Failed to load resource|fonts\.g|ERR_|offline|net::/i.test(m.text())) errors.push(m.text()); });
await page.goto(U); await page.evaluate(() => navigator.serviceWorker.ready); await page.waitForTimeout(500); await page.reload(); await page.waitForTimeout(500);
ok("service worker is active and controls the page", await page.evaluate(() => !!navigator.serviceWorker.controller));
ok("app shell cache created with hashed name", await page.evaluate(async () => (await caches.keys()).some(k => /^jarvis-shell-[0-9a-f]{8}$/.test(k))));
ok("shell files are cached", await page.evaluate(async () => { const c = await caches.open((await caches.keys())[0]); const ks = (await c.keys()).map(r => new URL(r.url).pathname); return ["/", "/app.js", "/offline.html", "/manifest.webmanifest"].every(p => ks.includes(p)); }));
ok("API calls are not cached", await page.evaluate(async () => { await fetch("/api/health"); const c = await caches.open((await caches.keys())[0]); return !(await c.keys()).some(r => r.url.includes("/api/")); }));
// installability, as Chrome sees it
const cdp = await ctx.newCDPSession(page); await cdp.send("Page.enable");
const inst = await cdp.send("Page.getInstallabilityErrors"); const ie = inst.installabilityErrors.filter(e => e.errorId !== "in-incognito"); // test contexts are always incognito-like
ok("Chrome reports no installability errors" + (ie.length ? " " + JSON.stringify(ie) : ""), ie.length === 0);
const mf = await cdp.send("Page.getAppManifest"); ok("Chrome parses the manifest without errors or warnings" + ((mf.errors || []).length ? " " + JSON.stringify(mf.errors) : ""), (mf.errors || []).length === 0 && /manifest/.test(mf.url));
// install prompt UI (Chrome fires the real event only on a real device)
await page.evaluate(() => { const e = new Event("beforeinstallprompt", { cancelable: true }); e.prompt = () => { window.__prompted = 1; }; e.userChoice = Promise.resolve({ outcome: "accepted" }); window.dispatchEvent(e); });
await page.waitForTimeout(100);
ok("install banner appears when the browser offers install", await page.evaluate(() => getComputedStyle(document.getElementById("ibanner")).display !== "none") && /Ready/.test(await page.evaluate(() => document.getElementById("instst").textContent)));
await page.evaluate(() => document.getElementById("ibyes").click()); await page.waitForTimeout(150);
ok("Install button calls the browser prompt and hides the banner", await page.evaluate(() => window.__prompted === 1 && getComputedStyle(document.getElementById("ibanner")).display === "none"));
// notifications through the service worker
await page.evaluate(() => go("settings")); await page.waitForTimeout(100);
ok("notification status shows On", /^On/.test(await page.evaluate(() => document.getElementById("notst").textContent)));
ok("reminder notification is shown by the service worker", await page.evaluate(async () => { await notify("JARVIS", "Reminder: test"); const r = await navigator.serviceWorker.getRegistration(); const n = await r.getNotifications(); return n.length === 1 && n[0].body === "Reminder: test"; }));
await page.evaluate(() => go("about")); await page.waitForTimeout(300);
ok("About shows offline ready and a version", /Ready/.test(await page.textContent("#aboff")) && /Version 0\.9/.test(await page.textContent("#abver")));
// offline
await ctx.setOffline(true); await page.waitForTimeout(300);
ok("offline banner is shown when the connection drops", await page.evaluate(() => getComputedStyle(document.getElementById("offbar")).display !== "none"));
await page.evaluate(() => go("tasks")); await page.fill("#tin", "Offline task"); await page.evaluate(() => document.getElementById("tadd").click()); await page.waitForTimeout(200);
ok("tasks still work offline", (await page.textContent("#tlist")).includes("Offline task"));
await page.evaluate(() => go("chat")); await page.fill("#cin", "hello"); await page.evaluate(() => document.getElementById("send").click()); await page.waitForTimeout(600);
ok("chat explains that it needs internet when offline", /needs internet/i.test(await page.textContent("#msgs")));
await page.reload(); await page.waitForTimeout(600);
ok("app opens offline from the cache", (await page.title()) === "JARVIS" && await page.evaluate(() => !!document.getElementById("home")));
await page.evaluate(() => go("tasks")); ok("offline task survived the offline reload", (await page.textContent("#tlist")).includes("Offline task"));
await page.goto(U + "does-not-exist").catch(() => {}); await page.waitForTimeout(300);
ok("unknown pages show the offline page", /You're offline/.test(await page.textContent("body")));
await ctx.setOffline(false); await page.goto(U); await page.waitForTimeout(600);
ok("back online: banner hidden and data kept", await page.evaluate(() => { go("settings"); return document.getElementById("storinfo").textContent.includes("1 tasks"); }));
// shortcuts and share target
await page.goto(U + "?go=tasks"); await page.waitForTimeout(500);
ok("shortcut ?go=tasks opens Tasks and cleans the URL", await page.evaluate(() => document.getElementById("tasks").classList.contains("on") && location.search === ""));
await page.goto(U + "?title=Note&text=Hello%20world"); await page.waitForTimeout(500);
ok("shared text lands in the chat box", await page.evaluate(() => document.getElementById("chat").classList.contains("on") && document.getElementById("cin").value === "Note Hello world"));
await page.goto(U + "?go=%3Cscript%3E"); await page.waitForTimeout(400);
ok("bad ?go= values are ignored safely", await page.evaluate(() => document.getElementById("home").classList.contains("on")));
ok("update check works over localhost", await page.evaluate(async () => { document.getElementById("abupd").click(); await new Promise(r => setTimeout(r, 800)); return /latest/.test(document.getElementById("abupds").textContent); }));
ok("no JavaScript or CSP errors", errors.length === 0 || (console.log(errors), false));
await browser.close(); server.close(); console.log(fail ? fail + " FAILED" : "ALL PASSED"); process.exit(fail ? 1 : 0);
