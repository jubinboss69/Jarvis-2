import http from "node:http";
import { server, safeEq, configWarnings } from "../src/index.js";
let fail = 0; const ok = (n, c) => { console.log((c ? "PASS " : "FAIL ") + n); if (!c) fail++; };
const mock = http.createServer((req, res) => {
  req.resume(); req.on("end", () => {
    if (req.headers.authorization === "Bearer BAD") { res.writeHead(401); return res.end('{"error":"bad key sk-SECRET"}'); }
    res.writeHead(200, { "Content-Type": "text/event-stream" });
    res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: "ok" } }] })}\n\n`); res.end("data: [DONE]\n\n");
  });
});
await new Promise(r => mock.listen(4401, r)); await new Promise(r => server.listen(4400, r));
Object.assign(process.env, { OPENAI_BASE_URL: "http://localhost:4401", OPENAI_API_KEY: "sk-SECRET-KEY-123", ACCESS_CODE: "a-long-private-code", RATE_PER_MIN: "100", DAILY_LIMIT: "1000" });
const B = "http://localhost:4400", good = { messages: [{ role: "user", content: "hi" }] };
const post = (h = {}, body = good) => fetch(B + "/api/chat", { method: "POST", headers: { "x-access-code": "a-long-private-code", ...h }, body: typeof body === "string" ? body : JSON.stringify(body) });
let r = await fetch(B + "/"); const h = r.headers;
ok("CSP: scripts only from self, no unsafe-inline for scripts", /script-src 'self'(;|$)/.test(h.get("content-security-policy")) && !/script-src[^;]*unsafe-inline/.test(h.get("content-security-policy")));
ok("CSP blocks framing, plugins and base tag", /frame-ancestors 'none'/.test(h.get("content-security-policy")) && /object-src 'none'/.test(h.get("content-security-policy")) && /base-uri 'none'/.test(h.get("content-security-policy")));
ok("X-Frame-Options, nosniff, no-referrer", h.get("x-frame-options") === "DENY" && h.get("x-content-type-options") === "nosniff" && h.get("referrer-policy") === "no-referrer");
ok("Permissions-Policy limits mic/geo to self", /microphone=\(self\)/.test(h.get("permissions-policy")) && /camera=\(\)/.test(h.get("permissions-policy")));
ok("no HSTS over plain http", !h.get("strict-transport-security"));
r = await fetch(B + "/", { headers: { "x-forwarded-proto": "https" } }); ok("HSTS when behind https proxy", /max-age=\d+/.test(r.headers.get("strict-transport-security")));
r = await fetch(B + "/api/health"); ok("API responses are not cached", r.headers.get("cache-control") === "no-store");
ok("health never reveals the key", !(await r.text()).includes("SECRET"));
ok("/app.js is served as javascript", (r = await fetch(B + "/app.js")).status === 200 && /javascript/.test(r.headers.get("content-type")));
for (const p of ["/.env", "/src/index.js", "/%2e%2e/src/index.js", "/..%2fsrc/index.js", "/package.json", "/.git/config"]) { r = await fetch(B + p); ok("static blocks " + p, r.status === 404 || r.status === 400); }
r = await post({ origin: "https://evil.example" }); ok("cross-origin POST -> 403", r.status === 403);
r = await post({ origin: "http://localhost:4400" }); ok("same-origin POST allowed", r.status === 200); await r.text();
ok("safeEq equal / different / different length", safeEq("abc", "abc") && !safeEq("abc", "abd") && !safeEq("abc", "abcd") && !safeEq("", "x"));
ok("wrong access code -> 401", (await post({ "x-access-code": "nope" })).status === 401);
ok("missing access code -> 401", (await fetch(B + "/api/chat", { method: "POST", body: JSON.stringify(good) })).status === 401);
r = await post(); ok("correct access code works", r.status === 200); await r.text();
ok("oversized body -> 413 and server survives", (await post({}, "x".repeat(300000)).catch(() => ({ status: 413 }))).status === 413 && (await fetch(B + "/api/health")).status === 200);
process.env.OPENAI_API_KEY = "BAD"; r = await post(); const tx = await r.text();
ok("upstream error is normalized and leaks no secrets", r.status === 502 && !tx.includes("SECRET") && !tx.includes("sk-"));
process.env.OPENAI_API_KEY = "sk-SECRET-KEY-123";
// brute force lockout (per IP)
process.env.AUTH_FAILS = "3";
const hdr = ip => ({ "x-forwarded-for": ip });
process.env.TRUST_PROXY = "1";
for (let i = 0; i < 3; i++) await post({ ...hdr("9.9.9.9"), "x-access-code": "wrong" + i });
r = await post(hdr("9.9.9.9")); ok("lockout after repeated wrong codes (even correct code is refused)", r.status === 429);
r = await post(hdr("8.8.8.8")); ok("other clients are not locked out", r.status === 200); await r.text();
// rate limit buckets follow X-Forwarded-For only when TRUST_PROXY=1
process.env.RATE_PER_MIN = "1";
r = await post(hdr("7.7.7.1")); await r.text(); ok("proxy mode: first request ok", r.status === 200);
r = await post(hdr("7.7.7.2")); await r.text(); ok("proxy mode: different client has its own bucket", r.status === 200);
r = await post(hdr("7.7.7.1")); ok("proxy mode: same client limited", r.status === 429);
process.env.TRUST_PROXY = ""; process.env.RATE_PER_MIN = "100";
await new Promise(r => setTimeout(r, 10));
const spoof = () => post({ "x-forwarded-for": String(Math.random()) });
process.env.RATE_PER_MIN = "2"; let codes = []; for (let i = 0; i < 4; i++) { r = await spoof(); codes.push(r.status); await r.text(); }
ok("without TRUST_PROXY a spoofed X-Forwarded-For cannot dodge the limit", codes.includes(429));
ok("config warnings: nothing set", configWarnings({}).length === 2);
ok("config warnings: short code", configWarnings({ OPENAI_API_KEY: "k", ACCESS_CODE: "short" }).length === 1);
ok("config warnings: good config", configWarnings({ OPENAI_API_KEY: "k", ACCESS_CODE: "a-long-private-code" }).length === 0);
server.close(); mock.close(); console.log(fail ? fail + " FAILED" : "ALL PASSED"); process.exit(fail ? 1 : 0);
