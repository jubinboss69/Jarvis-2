// Optional real-browser test (needs: npm i -D playwright && npx playwright install chromium)
import http from "node:http";
import { server } from "../src/index.js";
let pw; try { pw = await import("playwright"); } catch { pw = await import("/opt/npm-tools/node_modules/playwright/index.mjs"); }
const { chromium } = pw.chromium ? pw : pw.default;
let fail = 0; const ok = (n, c) => { console.log((c ? "PASS " : "FAIL ") + n); if (!c) fail++; };
const mock = http.createServer((req, res) => { req.resume(); req.on("end", () => { res.writeHead(200, { "Content-Type": "text/event-stream" }); for (const t of ["Hel", "lo there"]) res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: t } }] })}\n\n`); res.end("data: [DONE]\n\n"); }); });
await new Promise(r => mock.listen(4501, r)); await new Promise(r => server.listen(4500, r));
Object.assign(process.env, { OPENAI_BASE_URL: "http://localhost:4501", OPENAI_API_KEY: "k", ACCESS_CODE: "", RATE_PER_MIN: "100" });
const URL_ = "http://localhost:4500/";
const browser = await chromium.launch({ channel: "chromium" });
const errors = []; const watch = p => { p.on("pageerror", e => errors.push(String(e))); p.on("console", m => { if (m.type() === "error" && !/Failed to load resource|fonts\.g|ERR_/.test(m.text())) errors.push(m.text()); }); };
const info = async p => { await p.evaluate(() => go("settings")); await p.waitForTimeout(150); return p.textContent("#storinfo"); };
const click = (p, id) => p.evaluate(i => document.getElementById(i).click(), id);
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, acceptDownloads: true });
await ctx.addInitScript(() => { if (!localStorage.getItem("__seeded")) { localStorage.setItem("__seeded", "1");
  localStorage.setItem("jvchats", JSON.stringify([{ id: 1700000000000, title: "Old chat", msgs: [{ role: "user", content: "legacy hello" }, { role: "assistant", content: "legacy hi" }] }]));
  localStorage.setItem("jvrem", JSON.stringify([{ id: "r1", text: "Legacy reminder", at: Date.now() + 864e5, done: false }]));
  localStorage.setItem("jvevt", JSON.stringify([{ id: "e1", title: "Legacy event", date: "2030-01-01", time: "" }])); } });
let page = await ctx.newPage(); watch(page);
const resp = await page.goto(URL_); await page.waitForTimeout(400);
ok("page sends strict CSP header", /script-src 'self'/.test(resp.headers()["content-security-policy"]));
ok("legacy data migrated into IndexedDB", (await info(page)) === "1 chats · 0 tasks · 0 notes · 1 reminders · 1 events");
ok("legacy localStorage keys removed after migration", await page.evaluate(() => ["jvchats", "jvrem", "jvevt"].every(k => localStorage.getItem(k) === null)));
// XSS payloads must stay inert text
await page.evaluate(() => go("tasks")); await page.fill("#tin", "Buy milk"); await click(page, "tadd");
await page.fill("#tin", "<img src=x onerror=window.__xss=1>"); await click(page, "tadd");
await page.evaluate(() => go("notes")); await page.fill("#nin", "<script>window.__xss=2</script><b>bold</b>"); await click(page, "nadd");
await page.waitForTimeout(200);
ok("XSS payloads in tasks/notes are inert", await page.evaluate(() => window.__xss === undefined && !document.querySelector("#tlist img") && !document.querySelector("#nlist b")));
await page.evaluate(() => go("chat")); await page.fill("#cin", "hello <i>there</i>"); await click(page, "send");
await page.waitForFunction(() => document.querySelector("#msgs").textContent.includes("Hello there"), null, { timeout: 5000 });
ok("chat reply streamed", true); await page.waitForTimeout(300);
await page.reload(); await page.waitForTimeout(500);
ok("everything survives a reload", (await info(page)) === "2 chats · 2 tasks · 1 notes · 1 reminders · 1 events");
await page.evaluate(() => go("tasks")); ok("task text restored", (await page.textContent("#tlist")).includes("Buy milk"));
await page.evaluate(() => go("chat")); await click(page, "hist"); const hl = await page.textContent("#hlist");
ok("both chats in history", hl.includes("Old chat") && hl.includes("hello"));
await page.evaluate(() => go("settings")); await page.waitForTimeout(300);
ok("storage usage shown", /of/.test(await page.textContent("#storuse")));
await click(page, "storp"); await page.waitForTimeout(300); ok("persist request gives a status", (await page.textContent("#storps")).length > 5);
// granular delete
await click(page, "dtn"); await click(page, "dtn"); await page.waitForTimeout(200);
ok("delete tasks & notes (two taps)", (await info(page)).startsWith("2 chats · 0 tasks · 0 notes"));
await page.reload(); await page.waitForTimeout(500);
ok("deleted tasks/notes stay deleted, chats kept", (await info(page)).startsWith("2 chats · 0 tasks · 0 notes"));
await click(page, "drc"); ok("one tap does not delete (confirmation needed)", (await info(page)).endsWith("1 reminders · 1 events")); await click(page, "drc"); await page.waitForTimeout(200);
ok("delete reminders & calendar", (await info(page)).endsWith("0 reminders · 0 events"));
// auto-delete
await page.evaluate(() => { ST.keep = 7; save(); }); await page.reload(); await page.waitForTimeout(500);
ok("auto-delete removes only old chats", (await info(page)).startsWith("1 chats"));
// export
const dl = page.waitForEvent("download"); await click(page, "expd"); const d = await dl;
const fs = await import("node:fs"); const exp = JSON.parse(fs.readFileSync(await d.path(), "utf8"));
ok("export contains chats/tasks/settings but no secrets", Array.isArray(exp.chats) && exp.chats.length === 1 && "tasks" in exp && !JSON.stringify(exp).includes("jvpin") && !JSON.stringify(exp).includes("jvcode"));
// strict CSP blocks injected inline script
const before = errors.length; const injected = await page.evaluate(() => { const s = document.createElement("script"); s.textContent = "window.__csp=1"; document.head.appendChild(s); return window.__csp === 1; });
ok("injected inline script is blocked by CSP", injected === false); errors.length = before;
// delete everything
await page.evaluate(() => go("settings")); await click(page, "wipe"); await click(page, "wipe"); await page.waitForTimeout(400);
const raw = () => page.evaluate(() => new Promise(res => { const q = indexedDB.open("jarvis"); q.onsuccess = () => { const db = q.result, t = db.transaction(["kv", "chats"]); const a = t.objectStore("kv").count(), b = t.objectStore("chats").count(); t.oncomplete = () => { db.close(); res([a.result, b.result]); }; }; }));
ok("delete all empties IndexedDB", JSON.stringify(await raw()) === "[0,0]");
await page.reload(); await page.waitForTimeout(500);
const vals = () => page.evaluate(() => new Promise(res => { const q = indexedDB.open("jarvis"); q.onsuccess = () => { const db = q.result, t = db.transaction(["kv", "chats"]), a = t.objectStore("kv").getAll(), c = t.objectStore("chats").count(); t.oncomplete = () => { db.close(); res({ kv: a.result, chats: c.result }); }; }; }));
const v = await vals();
ok("still empty after reload (only the empty lists and a migration flag remain)", (await info(page)).startsWith("0 chats · 0 tasks · 0 notes · 0 reminders · 0 events") && v.chats === 0 && v.kv.every(x => x === 1 || (Array.isArray(x) && x.length === 0)));
ok("no JavaScript or CSP errors on the page", errors.length === 0 || (console.log(errors), false));
// fallback when IndexedDB is unavailable
const ctx2 = await browser.newContext({ viewport: { width: 390, height: 844 } });
await ctx2.addInitScript(() => Object.defineProperty(window, "indexedDB", { value: undefined, configurable: true }));
const p2 = await ctx2.newPage(); watch(p2); await p2.goto(URL_); await p2.waitForTimeout(400);
await p2.evaluate(() => go("tasks")); await p2.fill("#tin", "Fallback task"); await click(p2, "tadd"); await p2.reload(); await p2.waitForTimeout(500);
const fi = await info(p2); ok("fallback storage keeps data when IndexedDB is missing", fi.includes("1 tasks") && fi.includes("basic storage mode"));
ok("no errors in fallback mode", errors.length === 0 || (console.log(errors), false));
await browser.close(); server.close(); mock.close(); console.log(fail ? fail + " FAILED" : "ALL PASSED"); process.exit(fail ? 1 : 0);
