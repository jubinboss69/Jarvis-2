import http from "node:http";
import { server } from "../src/index.js";
let fail = 0; const ok = (n, c) => { console.log((c ? "PASS " : "FAIL ") + n); if (!c) fail++; };
let upstreamMode = "ok", lastBody = null;
const mock = http.createServer((req, res) => {
  let s = ""; req.on("data", c => s += c); req.on("end", () => {
    lastBody = JSON.parse(s);
    if (upstreamMode === "401") { res.writeHead(401); return res.end("{}"); }
    res.writeHead(200, { "Content-Type": "text/event-stream" });
    for (const t of ["Hel", "lo ", "আমি"]) res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: t } }] })}\n\n`);
    res.end("data: [DONE]\n\n");
  });
});
await new Promise(r => mock.listen(4101, r)); await new Promise(r => server.listen(4100, r));
process.env.OPENAI_BASE_URL = "http://localhost:4101"; process.env.OPENAI_API_KEY = "k"; process.env.ACCESS_CODE = "code";
const call = (body, code = "code") => fetch("http://localhost:4100/api/chat", { method: "POST", headers: { "x-access-code": code }, body: typeof body === "string" ? body : JSON.stringify(body) });
const good = { messages: [{ role: "user", content: "hi" }], settings: { name: "Jarvis", lang: "bn", model: "evil", temp: 9 } };
let r = await fetch("http://localhost:4100/api/health"); ok("health", (await r.json()).ok);
ok("no code -> 401", (await call(good, "bad")).status === 401);
ok("bad json -> 400", (await call("{nope")).status === 400);
ok("bad role -> 400", (await call({ messages: [{ role: "system", content: "x" }] })).status === 400);
ok("too long -> 400", (await call({ messages: [{ role: "user", content: "a".repeat(9000) }] })).status === 400);
r = await call(good); const txt = await r.text();
ok("stream 200", r.status === 200); ok("stream text + unicode", txt.includes('"Hel"') && txt.includes("আমি") && txt.includes("[DONE]"));
ok("model allowlisted", lastBody.model === "gpt-4o-mini"); ok("temp clamped", lastBody.temperature === 1);
ok("system prompt first, Bangla default", lastBody.messages[0].role === "system" && lastBody.messages[0].content.includes("Bangla"));
r = await call({ messages: [{ role: "user", content: "hi" }], settings: { me: "Rafi<script>", about: "Prefer short answers.\u0000 Use \"simple\" words." } }); await r.text();
ok("persona: name sanitized + about included", lastBody.messages[0].content.includes("The user's name is Rafiscript.") && lastBody.messages[0].content.includes("Prefer short answers.") && !lastBody.messages[0].content.includes("<script>") && lastBody.messages[0].content.includes("never override"));
r = await call({ messages: [{ role: "user", content: "hi" }], settings: { about: "x".repeat(900) } }); await r.text(); ok("about capped at 500 chars", lastBody.messages[0].content.match(/x{10,}/)[0].length === 500);
upstreamMode = "401"; r = await call(good); ok("upstream 401 -> 502 normalized", r.status === 502 && (await r.json()).error.includes("API key"));
upstreamMode = "ok"; process.env.OPENAI_API_KEY = ""; ok("no key -> 503", (await call(good)).status === 503);
process.env.OPENAI_API_KEY = "k"; process.env.RATE_PER_MIN = "2"; r = await call(good); ok("rate limit -> 429", r.status === 429);
r = await fetch("http://localhost:4100/../etc/passwd"); ok("path traversal blocked", r.status !== 200);
server.close(); mock.close(); console.log(fail ? fail + " FAILED" : "ALL PASSED"); process.exit(fail ? 1 : 0);
