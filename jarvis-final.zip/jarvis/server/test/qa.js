// Phase 10 QA: drives the real app in Chromium (phone size) with fake mic/speech and mock AI/weather/search.
import http from "node:http";
import { mkdirSync } from "node:fs";
import { server } from "../src/index.js";
let pw; try { pw = await import("playwright"); } catch { pw = await import("/opt/npm-tools/node_modules/playwright/index.mjs"); }
const { chromium } = pw.chromium ? pw : pw.default;
let fail = 0, total = 0; const ok = (n, c, d) => { total++; console.log((c ? "PASS " : "FAIL ") + n + (!c && d !== undefined ? "  -> " + (typeof d === "string" ? d : JSON.stringify(d)) : "")); if (!c) fail++; };
let aiMode = "ok", lastReq = null, reqs = 0;
const mock = http.createServer((req, res) => { let s = ""; req.on("data", c => s += c); req.on("end", () => {
  const u = new URL(req.url, "http://x"), j = o => { res.writeHead(200, { "Content-Type": "application/json" }); res.end(JSON.stringify(o)); };
  if (u.pathname === "/chat/completions") { reqs++; lastReq = JSON.parse(s); if (aiMode !== "ok") { res.writeHead(+aiMode); return res.end("{}"); }
    res.writeHead(200, { "Content-Type": "text/event-stream" }); for (const t of ["Hello ", "there"]) res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: t } }] })}\n\n`); return res.end("data: [DONE]\n\n"); }
  if (u.pathname === "/v1/search") return j(u.searchParams.get("name") === "Nowhere" ? {} : { results: [{ name: "Dhaka", admin1: "Dhaka", country: "Bangladesh", latitude: 23.7, longitude: 90.4 }] });
  if (u.pathname === "/v1/forecast") return j({ current: { temperature_2m: 29.4, relative_humidity_2m: 70, apparent_temperature: 33, weather_code: 2, wind_speed_10m: 11 }, daily: { time: ["2026-11-08", "2026-11-09", "2026-11-10"], weather_code: [2, 3, 61], temperature_2m_max: [33, 32, 31], temperature_2m_min: [25, 25, 24] } });
  if (u.pathname === "/res/v1/web/search") return j({ web: { results: [{ title: "<b>Pizza</b> guide", url: "https://a.com/p", description: "Best <b>pizza</b>" }] } });
  res.writeHead(404); res.end(); }); });
await new Promise(r => mock.listen(4901, r)); await new Promise(r => server.listen(4900, r));
Object.assign(process.env, { GEO_BASE: "http://localhost:4901", WEATHER_BASE: "http://localhost:4901", SEARCH_BASE: "http://localhost:4901", OPENAI_BASE_URL: "http://localhost:4901", OPENAI_API_KEY: "k", BRAVE_API_KEY: "bk", ACCESS_CODE: "", RATE_PER_MIN: "1000", TOOL_RATE_PER_MIN: "1000", DAILY_LIMIT: "100000" });
const U = "http://localhost:4900/";
const FAKES = `(()=>{window.__log=[];const L=(...a)=>window.__log.push(a);
window.open=u=>{L("open",String(u));return{}};
Object.defineProperty(navigator,"share",{value:d=>{L("share",d.text);return Promise.resolve()},configurable:true});
class R{constructor(){this.lang="";this.continuous=false;window.__rec=this}start(){L("rec-start",this.lang,this.continuous);setTimeout(()=>this.onstart&&this.onstart(),0)}abort(){L("rec-abort")}stop(){this.abort()}
emit(t,f=true){const r=Object.assign([{transcript:t}],{isFinal:f});this.onresult&&this.onresult({resultIndex:0,results:[r]});if(f&&!this.continuous)setTimeout(()=>this.onend&&this.onend(),5)}
fail(c){this.onerror&&this.onerror({error:c});setTimeout(()=>this.onend&&this.onend(),5)}}
if(!window.__noSR){window.SpeechRecognition=R;window.webkitSpeechRecognition=R}else{delete window.SpeechRecognition;delete window.webkitSpeechRecognition}
window.SpeechSynthesisUtterance=class{constructor(t){this.text=t;this.rate=1;this.pitch=1}};
Object.defineProperty(window,"speechSynthesis",{value:{speak(u){L("speak",u.text,u.lang,u.rate);setTimeout(()=>{u.onstart&&u.onstart();setTimeout(()=>u.onend&&u.onend(),30)},5)},cancel(){L("cancel")},getVoices:()=>[{name:"EN",lang:"en-US"},{name:"BN",lang:"bn-BD"}],onvoiceschanged:null},configurable:true});})()`;
const browser = await chromium.launch({ channel: "chromium" }); const errors = [];
async function fresh(opts = {}) {
  const ctx = await browser.newContext({ viewport: opts.vp || { width: 390, height: 844 }, permissions: ["clipboard-read", "clipboard-write", "geolocation"], geolocation: { latitude: 23.7, longitude: 90.4 }, acceptDownloads: true, serviceWorkers: "block" });
  if (opts.noSR) await ctx.addInitScript("window.__noSR=true"); await ctx.addInitScript(FAKES);
  const p = await ctx.newPage(); p.on("pageerror", e => errors.push("PAGEERR " + e)); p.on("console", m => { if (m.type() === "error" && !/Failed to load resource|fonts\.g|ERR_|status of (4|5)\d\d/.test(m.text())) errors.push("CONSOLE " + m.text()); });
  p.on("dialog", d => d.dismiss().catch(() => {})); await p.goto(U); await p.waitForTimeout(450); p.ctx = ctx; return p;
}
const log = p => p.evaluate(() => window.__log), opens = async p => (await log(p)).filter(x => x[0] === "open").map(x => x[1]);
const go = (p, s) => p.evaluate(s => go(s), s), tool = async (p, k) => { await p.evaluate(k => openTool(k), k); await p.waitForTimeout(120); };
const val = (p, id) => p.evaluate(i => document.getElementById(i).value, id), txt = (p, id) => p.evaluate(i => document.getElementById(i).textContent, id);
const clk = (p, id) => p.evaluate(i => document.getElementById(i).click(), id), put = (p, id, v) => p.fill("#" + id, v);
const say = async (p, t, w = 350) => { await go(p, "chat"); await put(p, "cin", t); await clk(p, "send"); await p.waitForTimeout(w); };
const lastAI = p => p.evaluate(() => { const a = [...document.querySelectorAll("#msgs .m.ai")].pop(); return a ? a.lastElementChild.textContent : ""; });
const screenOn = (p, s) => p.evaluate(s => document.getElementById(s).classList.contains("on"), s);

// ===== 1. NAVIGATION =====
let p = await fresh();
for (const s of ["home", "chat", "voice", "tools", "settings"]) { await p.locator(`nav button[data-go="${s}"]`).click(); await p.waitForTimeout(60); ok(`nav: ${s} opens`, await screenOn(p, s) && await p.evaluate(s => document.querySelector(`nav button[data-go="${s}"]`).getAttribute("aria-current") === "page", s)); }
const screens = await p.evaluate(() => [...document.querySelectorAll(".screen")].map(s => s.id)); let links = 0, badLinks = [];
for (const s of screens) { await go(p, s); const n = await p.evaluate(() => [...document.querySelectorAll(".screen.on [data-go]")].filter(e => e.offsetParent).length);
  for (let i = 0; i < n; i++) { await go(p, s); const t = await p.evaluate(i => { const e = [...document.querySelectorAll(".screen.on [data-go]")].filter(e => e.offsetParent)[i]; const g = e.dataset.go; e.click(); return g; }, i); links++; if (!(await screenOn(p, t))) badLinks.push(s + "->" + t); } }
ok(`navigation: all ${links} in-app links reach their screen`, badLinks.length === 0, badLinks);
const toolKeys = await p.evaluate(() => Object.keys(TOOLS)); ok("tools: 10 tools registered", toolKeys.length === 10, toolKeys);
for (const k of toolKeys) { await go(p, "tools"); await p.evaluate(k => document.querySelector(`[data-tool="${k}"]`).click(), k); await p.waitForTimeout(80); ok(`tools: "${k}" opens with a title`, await screenOn(p, "tool") && (await txt(p, "ttl")).length > 2); }

// ===== 2. DEAD-BUTTON CRAWL =====
const crawl = []; const all = [...screens.filter(s => s !== "tool"), ...toolKeys.map(k => "tool:" + k)]; let clicked = 0;
for (const s of all) {
  p = await fresh(); const [scr, k] = s.split(":"); const open = async () => { if (k) await tool(p, k); else await go(p, scr); };
  await open(); const n = await p.evaluate(() => [...document.querySelectorAll(".screen.on button")].filter(b => b.offsetParent && !b.closest("nav")).length);
  for (let i = 0; i < n; i++) {
    await open(); await p.evaluate(() => { window.__mut = 0; window.__mo && window.__mo.disconnect(); window.__mo = new MutationObserver(m => window.__mut += m.length); window.__mo.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true }); window.__log.length = 0; });
    const before = await p.evaluate(() => document.querySelector(".screen.on").id), dl = p.waitForEvent("download", { timeout: 250 }).then(() => 1).catch(() => 0), dg = p.waitForEvent("dialog", { timeout: 250 }).then(() => 1).catch(() => 0);
    const label = await p.evaluate(i => { const b = [...document.querySelectorAll(".screen.on button")].filter(b => b.offsetParent && !b.closest("nav"))[i]; b.__t = (b.getAttribute("aria-label") || b.textContent || b.id).trim().slice(0, 28); b.click(); return b.__t; }, i);
    await p.waitForTimeout(160); clicked++;
    const eff = (await p.evaluate(() => window.__mut)) > 0 || (await log(p)).length > 0 || (await p.evaluate(() => document.querySelector(".screen.on").id)) !== before || await dl || await dg;
    if (!eff) crawl.push(`${s}: "${label}"`);
    if (await p.evaluate(() => !!document.querySelector("[class*=lock],#lock,#pin"))) { await p.reload(); await p.waitForTimeout(400); }
  }
  await p.ctx.close();
}
ok(`dead-button crawl: all ${clicked} buttons do something`, crawl.length === 0, crawl);

// ===== 3. TOOLS =====
p = await fresh();
await tool(p, "calc"); for (const k of ["1", "2", "×", "5", "="]) await p.evaluate(k => [...document.querySelectorAll("#ckeys button")].find(b => b.textContent === k).click(), k);
ok("calculator: keypad 12×5 = 60", (await val(p, "cex")).includes("60") || (await txt(p, "cres")).includes("60"), [await val(p, "cex"), await txt(p, "cres")]);
for (const [e, want] of [["(2+3)*4", "20"], ["2^3^2", "512"], ["50%", "0.5"], ["sqrt(16)+1", "5"], ["10/4", "2.5"]]) { await put(p, "cex", e); await p.press("#cex", "Enter"); ok(`calculator: ${e} = ${want}`, ((await val(p, "cex")) + (await txt(p, "cres"))).includes(want), [await val(p, "cex"), await txt(p, "cres")]); }
await put(p, "cex", "1/0"); await p.press("#cex", "Enter"); ok("calculator: 1/0 shows an error, no crash", /zero|error|can't/i.test(await txt(p, "cres")), await txt(p, "cres"));
await put(p, "cex", "2+"); await p.press("#cex", "Enter"); ok("calculator: incomplete expression handled", (await txt(p, "cres")).length > 0);
ok("calculator: history kept", (await txt(p, "chist")).includes("20"));
await tool(p, "unit"); await put(p, "uv", "5"); await p.selectOption("#ucat", "length"); await p.selectOption("#uf", "km"); await p.selectOption("#ut", "mi");
ok("converter: 5 km = 3.10686 mi", (await txt(p, "ur")).includes("3.1068"), await txt(p, "ur"));
await clk(p, "usw"); ok("converter: swap reverses units", (await val(p, "uf")) === "mi" && (await val(p, "ut")) === "km");
await p.selectOption("#ucat", { label: "temp" }).catch(() => {}); const cats = await p.evaluate(() => [...document.querySelectorAll("#ucat option")].map(o => o.value)); ok("converter: has 7+ categories", cats.length >= 7, cats);
await p.selectOption("#ucat", cats.find(c => /temp/i.test(c))); await put(p, "uv", "100"); await p.selectOption("#uf", "C"); await p.selectOption("#ut", "F"); ok("converter: 100 C = 212 F", (await txt(p, "ur")).includes("212"), await txt(p, "ur"));
await put(p, "uv", ""); ok("converter: empty input does not crash", true);
await tool(p, "time"); const t1 = await txt(p, "tc"); await p.waitForTimeout(1200); ok("clock: shows time and ticks", /\d/.test(t1) && t1 !== await txt(p, "tc"));
ok("clock: date, zone and world clocks", (await txt(p, "td")).length > 8 && /Dhaka/.test(await txt(p, "tw")) && /London/.test(await txt(p, "tw")));
await tool(p, "weather"); await put(p, "wc", "Dhaka"); await clk(p, "wgo"); await p.waitForTimeout(500); ok("weather: city forecast shown", /Dhaka/.test(await txt(p, "wr")) && /29/.test(await txt(p, "wr")), await txt(p, "wr"));
await put(p, "wc", "Nowhere"); await clk(p, "wgo"); await p.waitForTimeout(400); ok("weather: unknown city gives a clear message", /couldn't find|not found|no match/i.test(await txt(p, "wr")), await txt(p, "wr"));
await clk(p, "wloc"); await p.waitForTimeout(700); ok("weather: use my location", /29|Your location|Dhaka/.test(await txt(p, "wr")), await txt(p, "wr"));
await tool(p, "rem"); await put(p, "rt", "Drink water"); const soon = await p.evaluate(() => { const d = new Date(Date.now() + 150000); d.setSeconds(0, 0); const z = n => String(n).padStart(2, "0"); return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}T${z(d.getHours())}:${z(d.getMinutes())}`; });
await put(p, "rw", soon); await clk(p, "radd"); await p.waitForTimeout(200); ok("reminders: added and listed", (await txt(p, "rl")).includes("Drink water"), await txt(p, "rl"));
await p.evaluate(() => { REMS[0].at = Date.now() - 1000; window.__log.length = 0; checkRem(); }); await p.waitForTimeout(300);
ok("reminders: due reminder alerts (toast + voice)", /Reminder: Drink water/.test(await txt(p, "toast")) && (await log(p)).some(x => x[0] === "speak" && /Drink water/.test(x[1])), [await txt(p, "toast"), await log(p)]);
await put(p, "rt", "Old one"); await put(p, "rw", "2020-01-01T10:00"); await clk(p, "radd"); await p.waitForTimeout(150); ok("reminders: a past time is refused with a message", /future|past|valid/i.test(await txt(p, "rmsg")), await txt(p, "rmsg"));
await put(p, "rt", ""); await clk(p, "radd"); ok("reminders: empty text is refused", true);
await p.evaluate(() => { REMS.push({ id: "m1", text: "Late one", at: Date.now() - 300000, done: false }); checkRem(); }); await p.waitForTimeout(150); ok("reminders: overdue shows 'Missed reminder'", /Missed reminder: Late one/.test(await txt(p, "toast")));
await tool(p, "cal"); const m0 = await txt(p, "cm"); await clk(p, "cn"); const m1 = await txt(p, "cm"); await clk(p, "cp"); ok("calendar: month navigation", m0 !== m1 && (await txt(p, "cm")) === m0);
await put(p, "cet", "Dentist"); await put(p, "cetm", "15:30"); await clk(p, "cea"); await p.waitForTimeout(150); ok("calendar: add event for the selected day", /Dentist/.test(await txt(p, "cel")) && /15:30|3:30/.test(await txt(p, "cel")), await txt(p, "cel"));
ok("calendar: day with an event is marked", await p.evaluate(() => [...document.querySelectorAll("#cg button")].some(b => b.querySelector("i,.dot,span") || /dot|mark|has/.test(b.className) || b.innerHTML.includes("<i"))));
await p.reload(); await p.waitForTimeout(500); await tool(p, "cal"); ok("calendar: event survives a reload", /Dentist/.test(await txt(p, "cel")), await txt(p, "cel"));
await p.evaluate(() => { const b = document.querySelector("#cel button"); b && b.click(); }); await p.waitForTimeout(100); ok("calendar: event can be deleted", !/Dentist/.test(await txt(p, "cel")), await txt(p, "cel"));
await tool(p, "trans"); await put(p, "tx", "Good morning"); await p.selectOption("#tl", { label: "Bangla" }); await clk(p, "tg"); await p.waitForTimeout(500);
ok("translate: result shown, Bangla requested", /Hello there/.test(await txt(p, "to")) && /Bangla/.test(lastReq.messages[0].content), [await txt(p, "to"), lastReq && lastReq.messages[0].content]);
reqs = 0; await put(p, "tx", ""); await clk(p, "tg"); await p.waitForTimeout(200); ok("translate: empty text sends nothing", reqs === 0);
aiMode = "429"; await put(p, "tx", "Hi"); await clk(p, "tg"); await p.waitForTimeout(400); ok("translate: provider error shown clearly", /rate limit/i.test(await txt(p, "to")), await txt(p, "to")); aiMode = "ok";
await tool(p, "sum"); await put(p, "sx", "A long text to summarize."); await p.selectOption("#sf", { index: 1 }); await clk(p, "sg"); await p.waitForTimeout(500); ok("summarizer: result shown with chosen format", /Hello there/.test(await txt(p, "so")) && /Summarize/i.test(lastReq.messages[0].content), await txt(p, "so"));
await tool(p, "search"); await put(p, "sq", "pizza near me"); await p.evaluate(() => document.querySelector("#seng button").click()); await p.waitForTimeout(250); ok("search: Google opens with the query", (await opens(p)).some(u => /google\.com\/search\?q=pizza%20near%20me/.test(u)), await opens(p));
await p.evaluate(() => [...document.querySelectorAll("#seng button")][1].click()); await p.waitForTimeout(250); ok("search: DuckDuckGo opens", (await opens(p)).some(u => /duckduckgo\.com/.test(u)));
const engines = await p.evaluate(() => [...document.querySelectorAll("#seng button")].map(b => b.textContent)); const inapp = engines.findIndex(e => /app|result|brave|here/i.test(e));
if (inapp >= 0) { await p.evaluate(i => document.querySelectorAll("#seng button")[i].click(), inapp); await p.waitForTimeout(500); ok("search: in-app results with cleaned text", /Pizza guide/.test(await txt(p, "sres")) && !/<b>/.test(await txt(p, "sres")), await txt(p, "sres")); } else ok("search: in-app results button exists", false, engines);
await tool(p, "browser"); await put(p, "bu", "example.com"); await clk(p, "bgo"); await p.waitForTimeout(300); ok("browser: opens a typed site", (await opens(p)).some(u => u === "https://example.com"), await opens(p));
await put(p, "bu", "not a url"); await clk(p, "bgo"); await p.waitForTimeout(250); ok("browser: invalid address is refused", !(await opens(p)).some(u => /not%20a%20url|not a url/.test(u)));
ok("browser: quick links listed", (await txt(p, "bl")).length > 10);
await go(p, "apps"); await put(p, "an", "Daraz"); await put(p, "al", "https://www.daraz.com.bd"); await clk(p, "aadd"); ok("apps: custom app added", /Daraz/.test(await txt(p, "alist")));
await put(p, "an", "Bad"); await put(p, "al", "javascript://alert(1)"); await clk(p, "aadd"); ok("apps: javascript: link refused", !/Bad/.test(await txt(p, "alist")) && /isn't allowed|valid/i.test(await txt(p, "amsg")), await txt(p, "amsg"));
await say(p, "open daraz"); ok("apps: custom app opens by voice/typed command", (await opens(p)).some(u => /daraz/.test(u)), await opens(p));
await p.evaluate(() => document.querySelector('#alist [data-del]').click()); ok("apps: custom app deleted", !/Daraz/.test(await txt(p, "alist")));
await p.ctx.close();

// ===== 4. COMMANDS & APP LAUNCHING (desktop mode: window.open is observed) =====
p = await fresh();
const open1 = async (t, re) => { await p.evaluate(() => window.__log.length = 0); await say(p, t); const o = await opens(p); ok(`command "${t}" opens ${re}`, o.some(u => re.test(u)), o); };
await open1("open YouTube", /youtube\.com/); await open1("open gmail", /mail\.google\.com/); await open1("open whatsapp", /whatsapp/); await open1("open spotify", /spotify/); await open1("open instagram", /instagram/); await open1("open facebook", /facebook/); await open1("open telegram", /telegram/); await open1("open maps", /google\.com\/maps/);
await open1("open example.com", /example\.com/); await open1("search for best pizza", /google\.com\/search\?q=best%20pizza/); await open1("search youtube for lofi music", /youtube\.com\/results\?search_query=lofi%20music/); await open1("navigate to Dhaka airport", /maps.*Dhaka%20airport/);
await say(p, "open nothingknown"); ok("command: unknown app says it is not in the list", /list/i.test(await lastAI(p)), await lastAI(p));
await say(p, "open settings"); ok("command: phone settings explained as unsupported", /can't open phone settings/i.test(await lastAI(p)), await lastAI(p));
await say(p, "copy hello world"); await p.waitForTimeout(150); ok("command: copy puts text on the clipboard", (await p.evaluate(() => navigator.clipboard.readText())) === "hello world" && /Copied/.test(await lastAI(p)), await lastAI(p));
await p.evaluate(() => window.__log.length = 0); await say(p, "share see you at 5"); ok("command: share asks for confirmation first", /Confirm/.test(await p.evaluate(() => document.querySelector("#msgs").textContent)) && !(await log(p)).some(x => x[0] === "share"));
await p.locator("#msgs button", { hasText: "Cancel" }).last().click(); await p.waitForTimeout(150); ok("command: Cancel stops the share", /Cancelled/.test(await lastAI(p)) && !(await log(p)).some(x => x[0] === "share"));
await say(p, "share see you at 5"); await p.locator("#msgs button", { hasText: "Confirm" }).last().click(); await p.waitForTimeout(200); ok("command: Confirm shares the text", (await log(p)).some(x => x[0] === "share" && x[1] === "see you at 5"), await log(p));
await p.evaluate(() => window.__log.length = 0); await say(p, "call 01712345678"); ok("command: call needs confirmation", !(await opens(p)).length && /dialer/i.test(await lastAI(p)));
await say(p, "confirm"); await p.waitForTimeout(300); ok('command: typing "confirm" opens the dialer', (await opens(p)).some(u => u === "tel:01712345678"), await opens(p));
await say(p, "email a@b.com"); await say(p, "no"); ok('command: "no" cancels the email', !(await opens(p)).some(u => /mailto/.test(u)) && /Cancelled/.test(await lastAI(p)));
await say(p, "add task Buy rice"); await say(p, "note remember the milk"); await go(p, "tasks"); ok("command: add task / note", /Buy rice/.test(await txt(p, "tlist")) && /remember the milk/.test(await txt(p, "nlist")));
await say(p, "what is 15% of 200"); ok("command: percent calculation = 30", /30/.test(await lastAI(p)), await lastAI(p)); await say(p, "calculate 12 x 12"); ok("command: calculate 12 x 12 = 144", /144/.test(await lastAI(p)), await lastAI(p));
await say(p, "convert 5 km to miles"); ok("command: convert", /3\.1/.test(await lastAI(p)), await lastAI(p)); await say(p, "what time is it"); ok("command: time", /\d/.test(await lastAI(p)) && /(AM|PM|\d\d:\d\d)/i.test(await lastAI(p)), await lastAI(p));
await say(p, "weather in Dhaka", 700); ok("command: weather", /29/.test(await lastAI(p)), await lastAI(p)); await say(p, "remind me to stretch in 10 minutes"); ok("command: reminder created", /stretch/i.test(await lastAI(p)) && await p.evaluate(() => REMS.some(r => /stretch/i.test(r.text))), await lastAI(p));
await say(p, "schedule dentist tomorrow at 3pm"); ok("command: schedule event", await p.evaluate(() => EVTS.some(e => /dentist/i.test(e.title))), await lastAI(p));
await say(p, "go to settings"); ok("command: go to settings", await screenOn(p, "settings")); await p.ctx.close();

// ===== 5. AI CHAT =====
p = await fresh(); reqs = 0; await say(p, "Hello JARVIS", 600); ok("chat: streamed reply appears", /Hello there/.test(await lastAI(p)), await lastAI(p));
await say(p, "And again", 600); ok("chat: earlier messages are sent as context", lastReq.messages.filter(m => m.role !== "system").length === 3, lastReq.messages.map(m => m.role));
ok("chat: assistant name and language reach the system prompt", /JARVIS/.test(lastReq.messages[0].content));
await p.evaluate(() => { ST.me = "Rafi"; ST.about = "I like short answers"; save(); }); await say(p, "Hi", 500); ok("chat: your name and notes reach the AI", /Rafi/.test(lastReq.messages[0].content) && /short answers/.test(lastReq.messages[0].content), lastReq.messages[0].content);
reqs = 0; await go(p, "chat"); await put(p, "cin", "   "); await clk(p, "send"); await p.waitForTimeout(200); ok("chat: blank message is ignored", reqs === 0);
await say(p, "x".repeat(8100), 500); ok("chat: over-long message gets a clear error, app keeps working", /invalid|long/i.test(await lastAI(p)), await lastAI(p).then(t => t.slice(0, 80)));
for (const [mode, re] of [["401", /rejected the API key/i], ["429", /rate limiting/i], ["500", /provider had an error/i]]) { aiMode = mode; await say(p, "test " + mode, 500); ok(`chat: provider ${mode} -> readable error`, re.test(await lastAI(p)), await lastAI(p)); } aiMode = "ok";
await say(p, "back to normal", 500); ok("chat: recovers after errors", /Hello there/.test(await lastAI(p)));
process.env.OPENAI_API_KEY = ""; await say(p, "no key", 400); ok("chat: missing server key -> clear message", /no API key/i.test(await lastAI(p)), await lastAI(p)); process.env.OPENAI_API_KEY = "k";
await p.reload(); await p.waitForTimeout(500); await go(p, "chat"); await clk(p, "hist"); ok("chat: history is kept after reload", /Hello JARVIS/.test(await txt(p, "hlist")), await txt(p, "hlist"));
await clk(p, "newc"); ok("chat: new chat starts empty", (await p.evaluate(() => document.querySelectorAll("#msgs .m.me").length)) === 0);
process.env.ACCESS_CODE = "a-long-private-code"; p.removeAllListeners("dialog"); p.on("dialog", d => d.accept("a-long-private-code")); await say(p, "needs code", 500);
ok("chat: access code prompt appears and tells you to resend", /Access code needed/.test(await lastAI(p)), await lastAI(p)); await say(p, "second try", 600); ok("chat: works after entering the code", /Hello there/.test(await lastAI(p)), await lastAI(p)); process.env.ACCESS_CODE = "";
const t0 = Date.now(); await p.evaluate(() => { const c = cur(); for (let i = 0; i < 200; i++) c.msgs.push({ role: i % 2 ? "assistant" : "user", content: "Message number " + i + " with some text to wrap around the screen a bit" }); renderChat(); }); const rt = Date.now() - t0; ok(`performance: 200-message chat renders in ${rt} ms`, rt < 1000);
await p.ctx.close();

// ===== 6. VOICE =====
p = await fresh(); await go(p, "voice"); await clk(p, "mic"); await p.waitForTimeout(100); ok("voice: mic starts recognition in English", (await log(p)).some(x => x[0] === "rec-start" && x[1] === "en-US"), await log(p)); ok("voice: listening state shown", /Listening/.test(await txt(p, "vstat")) && await p.evaluate(() => document.getElementById("mic").classList.contains("on")));
await p.evaluate(() => window.__rec.emit("add task voice milk")); await p.waitForTimeout(300); ok("voice: spoken command runs (add task)", await p.evaluate(() => tasks.some(t => /voice milk/i.test(t.x))));
ok("voice: reply is spoken aloud", (await log(p)).some(x => x[0] === "speak" && /Task added/.test(x[1])), await log(p));
await clk(p, "mic"); await p.evaluate(() => window.__rec.emit("tell me a joke")); await p.waitForTimeout(700); ok("voice: AI answer shown on the voice screen and spoken", /Hello there/.test(await txt(p, "vans")) && (await log(p)).some(x => x[0] === "speak" && /Hello there/.test(x[1])), [await txt(p, "vans")]);
await clk(p, "mic"); await p.evaluate(() => window.__rec.emit("open youtube")); await p.waitForTimeout(300); ok("voice: 'open youtube' launches it", (await opens(p)).some(u => /youtube/.test(u)));
await p.evaluate(() => window.__log.length = 0); await p.evaluate(() => { ST.voice = false; save(); apply(); }); await clk(p, "mic"); await p.evaluate(() => window.__rec.emit("add task silent")); await p.waitForTimeout(300); ok("voice: replies are silent when 'Speak replies' is off", !(await log(p)).some(x => x[0] === "speak"));
await p.evaluate(() => { ST.voice = true; ST.lang = "bn"; save(); apply(); }); await p.evaluate(() => window.__log.length = 0); await clk(p, "mic"); await p.waitForTimeout(100); ok("voice: Bangla setting uses bn-BD recognition", (await log(p)).some(x => x[0] === "rec-start" && x[1] === "bn-BD"), await log(p));
await p.evaluate(() => { window.__rec.emit("থামো"); }); await p.waitForTimeout(200); ok("voice: Bangla 'stop' is understood", !(await p.evaluate(() => document.getElementById("mic").classList.contains("on"))));
await p.evaluate(() => { ST.lang = "en"; save(); apply(); }); await clk(p, "mic"); await p.evaluate(() => window.__rec.fail("not-allowed")); await p.waitForTimeout(200); ok("voice: blocked microphone explained", /permission is blocked/i.test(await txt(p, "vnote")), await txt(p, "vnote"));
await clk(p, "mic"); await p.waitForTimeout(100); ok("voice: tapping again after an error retries", (await log(p)).filter(x => x[0] === "rec-start").length >= 2);
await p.evaluate(() => { ST.wake = true; save(); apply(); window.__log.length = 0; go("home"); go("voice"); }); await p.waitForTimeout(200); ok("voice: wake word listens continuously on the Voice screen", (await log(p)).some(x => x[0] === "rec-start" && x[2] === true), await log(p));
await p.evaluate(() => window.__rec.emit("jarvis open spotify")); await p.waitForTimeout(300); ok("voice: wake word + command runs", (await opens(p)).some(u => /spotify/.test(u)), await opens(p));
await p.evaluate(() => window.__log.length = 0); await go(p, "chat"); ok("voice: leaving the Voice screen stops listening", (await log(p)).some(x => x[0] === "rec-abort"), await log(p));
await p.ctx.close(); p = await fresh({ noSR: true }); await go(p, "voice"); await clk(p, "mic"); ok("voice: unsupported browser gets a clear message", /doesn't support speech/i.test(await txt(p, "vnote")), await txt(p, "vnote")); await p.ctx.close();

// ===== 7. RESPONSIVE, THEMES, BANGLA, CONTRAST =====
mkdirSync("/tmp/qa-shots", { recursive: true }); const lum = c => { const a = c.map(v => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; }); return .2126 * a[0] + .7152 * a[1] + .0722 * a[2]; };
for (const [w, h] of [[320, 568], [360, 740], [412, 915], [768, 1024]]) { p = await fresh({ vp: { width: w, height: h } }); const bad = [];
  for (const s of screens.filter(s => s !== "tool")) { await go(p, s); await p.waitForTimeout(60); const o = await p.evaluate(() => [document.documentElement.scrollWidth, document.querySelector("main").scrollWidth, innerWidth]); if (o[0] > o[2] + 1 || o[1] > o[2] + 1) bad.push(s); }
  for (const k of toolKeys) { await tool(p, k); const o = await p.evaluate(() => [document.documentElement.scrollWidth, document.querySelector("main").scrollWidth, innerWidth]); if (o[0] > o[2] + 1 || o[1] > o[2] + 1) bad.push("tool:" + k); }
  ok(`responsive ${w}x${h}: no horizontal overflow on any screen or tool`, bad.length === 0, bad); await p.ctx.close(); }
for (const [theme, lang] of [["dark", "en"], ["light", "en"], ["dark", "bn"], ["light", "bn"]]) { p = await fresh(); await p.evaluate(([t, l]) => { ST.theme = t; ST.lang = l; save(); apply(); }, [theme, lang]); await p.waitForTimeout(250); const bad = [];
  for (const s of screens.filter(s => s !== "tool")) { await go(p, s); await p.waitForTimeout(60); const o = await p.evaluate(() => [document.documentElement.scrollWidth, innerWidth]); if (o[0] > o[1] + 1) bad.push(s); }
  ok(`${theme}/${lang}: no overflow`, bad.length === 0, bad);
  if (lang === "bn") ok("bangla: navigation labels translated and page lang set", await p.evaluate(() => /[\u0980-\u09FF]/.test(document.querySelector('nav button[data-go="settings"]').textContent) && document.documentElement.lang === "bn"));
  const pairs = await p.evaluate(() => { const rgb = s => (s.match(/[\d.]+/g) || []).map(Number); const bgOf = e => { let n = e; const layers = []; while (n) { const c = rgb(getComputedStyle(n).backgroundColor); if (c.length && (c[3] === undefined || c[3] > 0)) { layers.push(c); if (c[3] === undefined || c[3] >= 1) break; } n = n.parentElement; } let base = [255, 255, 255]; const rb = rgb(getComputedStyle(document.body).backgroundColor); if (rb.length) base = rb.slice(0, 3); for (const l of layers.reverse()) { const a = l[3] === undefined ? 1 : l[3]; base = base.map((v, i) => l[i] * a + v * (1 - a)); } return base; };
    const out = []; const add = (name, sel) => { const e = document.querySelector(sel); if (!e || !e.offsetParent) return; out.push([name, rgb(getComputedStyle(e).color).slice(0, 3), bgOf(e)]); };
    add("body text", "#greet"); add("muted text", "#clock"); add("card text", ".stat b"); add("nav inactive", "nav button:not(.on)"); add("nav active", "nav button.on"); add("button text", "#hgo"); add("chip", ".chip"); return out; });
  const lows = pairs.map(([n, f, b]) => { const l1 = lum(f), l2 = lum(b), r = (Math.max(l1, l2) + .05) / (Math.min(l1, l2) + .05); return [n, +r.toFixed(2)]; }).filter(x => x[1] < 4.5);
  ok(`${theme}/${lang}: text contrast is at least 4.5:1`, lows.length === 0, lows);
  if (lang === "en") { await go(p, "home"); await p.screenshot({ path: `/tmp/qa-shots/home-${theme}.png` }); await go(p, "settings"); await p.screenshot({ path: `/tmp/qa-shots/settings-${theme}.png` }); } await p.ctx.close(); }
p = await fresh(); await tool(p, "calc"); await p.screenshot({ path: "/tmp/qa-shots/calc.png" }); await tool(p, "cal"); await p.screenshot({ path: "/tmp/qa-shots/cal.png" }); await go(p, "voice"); await p.screenshot({ path: "/tmp/qa-shots/voice.png" });

// ===== 8. ROBUSTNESS =====
await go(p, "tasks"); await put(p, "tin", "L".repeat(5000)); await clk(p, "tadd"); await p.waitForTimeout(150); ok("robustness: 5000-character task does not break the layout", await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1));
await put(p, "tin", "   "); const n0 = await p.evaluate(() => tasks.length); await clk(p, "tadd"); ok("robustness: blank task is ignored", (await p.evaluate(() => tasks.length)) === n0);
await put(p, "tin", "Emoji 😀 বাংলা العربية"); await clk(p, "tadd"); await p.waitForTimeout(100); ok("robustness: emoji, Bangla and Arabic text kept intact", /Emoji 😀 বাংলা العربية/.test(await txt(p, "tlist")));
for (let i = 0; i < 5; i++) await clk(p, "tadd"); await p.evaluate(() => { for (let i = 0; i < 3; i++) document.getElementById("send") && 0; }); ok("robustness: rapid repeated clicks do not throw", true);
const load = await p.evaluate(() => { const n = performance.getEntriesByType("navigation")[0]; return Math.round(n.domContentLoadedEventEnd); }); ok(`performance: DOM ready in ${load} ms (local)`, load < 2000);
const sz = await p.evaluate(async () => { const r = await fetch("/app.js"); return (await r.text()).length; }); ok(`performance: app.js is ${Math.round(sz / 1024)} KB (limit 150 KB)`, sz < 150 * 1024);
ok("no JavaScript or CSP errors during the whole run", errors.length === 0, errors.slice(0, 8));
await browser.close(); server.close(); mock.close(); console.log(`\n${total - fail}/${total} passed` + (fail ? `, ${fail} FAILED` : "")); process.exit(fail ? 1 : 0);
