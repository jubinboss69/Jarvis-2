import { readFileSync, existsSync } from "node:fs";
import { server } from "../src/index.js";
let fail = 0; const ok = (n, c) => { console.log((c ? "PASS " : "FAIL ") + n); if (!c) fail++; };
const pub = f => new URL("../public/" + f, import.meta.url);
const html = readFileSync(pub("index.html"), "utf8"), man = JSON.parse(readFileSync(pub("manifest.webmanifest"), "utf8")), sw = readFileSync(pub("sw.js"), "utf8");
const png = f => { const b = readFileSync(pub(f)); return b.subarray(0, 8).toString("hex") === "89504e470d0a1a0a" ? [b.readUInt32BE(16), b.readUInt32BE(20)] : null; };
ok("manifest: name, short_name, start_url, scope, id", man.name && man.short_name === "JARVIS" && man.start_url === "/" && man.scope === "/" && man.id === "/");
ok("manifest: standalone display, portrait, dark colors", man.display === "standalone" && man.background_color === "#0a0e15" && man.theme_color === "#0a0e15");
for (const [size, purpose] of [[192, "any"], [512, "any"], [512, "maskable"]]) {
  const i = man.icons.find(x => x.sizes === `${size}x${size}` && x.purpose === purpose);
  ok(`icon ${size} ${purpose} exists with real PNG size`, !!i && existsSync(pub(i.src.slice(1))) && JSON.stringify(png(i.src.slice(1))) === `[${size},${size}]`);
}
ok("apple-touch-icon is 180x180 and favicon 32x32", JSON.stringify(png("icons/apple-touch-icon.png")) === "[180,180]" && JSON.stringify(png("icons/favicon-32.png")) === "[32,32]");
ok("shortcuts point at real screens", man.shortcuts.length >= 3 && man.shortcuts.every(x => { const g = new URL(x.url, "http://x").searchParams.get("go"); return html.includes(`id="${g}"`); }));
ok("share target is GET with text params", man.share_target && man.share_target.method === "GET" && man.share_target.params.text === "text");
ok("page links manifest, icons, theme-color, safe-area viewport", ["rel=\"manifest\" href=\"/manifest.webmanifest\"", "rel=\"apple-touch-icon\"", "name=\"theme-color\"", "viewport-fit=cover", "rel=\"icon\""].every(x => html.includes(x)));
ok("page registers the service worker from app.js", readFileSync(pub("app.js"), "utf8").includes('register("/sw.js")'));
const shell = [...sw.matchAll(/"(\/[^"]*)"/g)].map(m => m[1]).filter(x => x.length > 1 && !x.startsWith("/api"));
ok("every precached file exists", shell.length >= 5 && shell.every(f => existsSync(pub(f.slice(1)))), shell.filter(f => !existsSync(pub(f.slice(1)))));
ok("service worker never caches API calls or non-GET", /startsWith\("\/api\/"\)/.test(sw) && /req\.method !== "GET"/.test(sw));
const off = readFileSync(pub("offline.html"), "utf8");
ok("offline page is self-contained (no scripts, no external files)", !/<script/i.test(off) && !/https?:\/\//i.test(off.replace(/<[^>]*xmlns[^>]*>/g, "")));
await new Promise(r => server.listen(4600, r)); const B = "http://localhost:4600";
let r = await fetch(B + "/manifest.webmanifest"); ok("manifest served with correct type", r.status === 200 && /manifest\+json/.test(r.headers.get("content-type")));
r = await fetch(B + "/sw.js"); const t1 = await r.text();
ok("sw.js served with a content-hash cache name", r.status === 200 && /jarvis-shell-[0-9a-f]{8}"/.test(t1) && !t1.includes("jarvis-shell-v1") && r.headers.get("service-worker-allowed") === "/");
ok("sw.js is not cached by the browser", /no-cache/.test(r.headers.get("cache-control")));
for (const f of ["/offline.html", "/icons/icon-192.png", "/icons/maskable-512.png", "/icons/apple-touch-icon.png"]) ok("serves " + f, (await fetch(B + f)).status === 200);
server.close(); console.log(fail ? fail + " FAILED" : "ALL PASSED"); process.exit(fail ? 1 : 0);
