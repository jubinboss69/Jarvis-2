import http from "node:http";
import { server } from "../src/index.js";
let fail = 0; const ok = (n, c) => { console.log((c ? "PASS " : "FAIL ") + n); if (!c) fail++; };
let forecastCalls = 0, sysPrompt = "", braveToken = "";
const mock = http.createServer((req, res) => {
  const u = new URL(req.url, "http://x"); let s = ""; req.on("data", c => s += c);
  req.on("end", () => {
    const j = o => { res.writeHead(200, { "Content-Type": "application/json" }); res.end(JSON.stringify(o)); };
    if (u.pathname === "/v1/search") return j(u.searchParams.get("name") === "Nowhere" ? {} : { results: [{ name: "Dhaka", admin1: "Dhaka", country: "Bangladesh", latitude: 23.7, longitude: 90.4 }] });
    if (u.pathname === "/v1/forecast") { forecastCalls++; return j({ current: { temperature_2m: 29.4, relative_humidity_2m: 70, apparent_temperature: 33, weather_code: 2, wind_speed_10m: 11 }, daily: { time: ["2026-11-06", "2026-11-07", "2026-11-08"], weather_code: [2, 61, 0], temperature_2m_max: [31, 30, 32], temperature_2m_min: [22, 21, 23] } }); }
    if (u.pathname === "/res/v1/web/search") { braveToken = req.headers["x-subscription-token"]; return j({ web: { results: [{ title: "<b>Pizza</b> guide", url: "https://a.com/p", description: "Best <i>pizza</i>" }, { title: "bad", url: "javascript:alert(1)", description: "x" }] } }); }
    if (u.pathname === "/chat/completions") { sysPrompt = JSON.parse(s).messages[0].content; res.writeHead(200, { "Content-Type": "text/event-stream" }); res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: "ok" } }] })}\n\n`); return res.end("data: [DONE]\n\n"); }
    res.writeHead(404); res.end();
  });
});
await new Promise(r => mock.listen(4201, r)); await new Promise(r => server.listen(4200, r));
Object.assign(process.env, { GEO_BASE: "http://localhost:4201", WEATHER_BASE: "http://localhost:4201", SEARCH_BASE: "http://localhost:4201", OPENAI_BASE_URL: "http://localhost:4201", OPENAI_API_KEY: "k", ACCESS_CODE: "code", TOOL_RATE_PER_MIN: "50", DAILY_LIMIT: "999", RATE_PER_MIN: "99" });
const B = "http://localhost:4200", H = { "x-access-code": "code" };
const get = (p, h = H) => fetch(B + p, { headers: h });
let r = await get("/api/weather?city=Dhaka"); let d = await r.json();
ok("weather city 200", r.status === 200 && d.place === "Dhaka, Dhaka, Bangladesh" && d.days.length === 3 && d.temp === 29.4);
await get("/api/weather?city=Dhaka"); ok("weather cached (1 forecast call)", forecastCalls === 1);
r = await get("/api/weather?lat=23.7&lon=90.4"); d = await r.json(); ok("weather by coordinates", r.status === 200 && d.place === "Your location");
ok("unknown city -> 404", (await get("/api/weather?city=Nowhere")).status === 404);
ok("missing city -> 400", (await get("/api/weather")).status === 400);
ok("weather needs access code", (await get("/api/weather?city=Dhaka", {})).status === 401);
ok("search not configured -> 503", (await get("/api/search?q=pizza")).status === 503);
process.env.BRAVE_API_KEY = "bk";
r = await get("/api/search?q=pizza"); d = await r.json();
ok("search cleaned + filtered", r.status === 200 && d.results.length === 1 && d.results[0].title === "Pizza guide" && d.results[0].desc === "Best pizza");
ok("search sends token", braveToken === "bk"); ok("search empty -> 400", (await get("/api/search?q=")).status === 400);
ok("health shows search", (await (await get("/api/health")).json()).search === true);
const chat = o => fetch(B + "/api/chat", { method: "POST", headers: H, body: JSON.stringify({ messages: [{ role: "user", content: "hello" }], ...o }) });
await (await chat({ mode: "translate", opt: { to: "Bangla" } })).text(); ok("translate prompt", sysPrompt.includes("into Bangla") && sysPrompt.includes("Output only the translation"));
await (await chat({ mode: "translate", opt: { to: "Klingon" } })).text(); ok("bad language falls back to English", sysPrompt.includes("into English"));
await (await chat({ mode: "summarize", opt: { fmt: "bullets" } })).text(); ok("summarize bullets prompt", sysPrompt.includes("bullet points"));
await (await chat({})).text(); ok("normal chat prompt unchanged", sysPrompt.includes("personal AI assistant"));
process.env.TOOL_RATE_PER_MIN = "2"; r = await get("/api/weather?city=Dhaka"); ok("tool rate limit -> 429", r.status === 429);
server.close(); mock.close(); console.log(fail ? fail + " FAILED" : "ALL PASSED"); process.exit(fail ? 1 : 0);
