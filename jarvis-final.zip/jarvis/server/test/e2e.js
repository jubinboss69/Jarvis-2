// Phase 10: full end-to-end QA in a real browser (needs playwright + chromium)
import http from "node:http";
import { server } from "../src/index.js";
let pw; try { pw = await import("playwright"); } catch { pw = await import("/opt/npm-tools/node_modules/playwright/index.mjs"); }
const { chromium } = pw.chromium ? pw : pw.default;
let fail = 0; const notes = []; const ok = (n, c, extra) => { console.log((c ? "PASS " : "FAIL ") + n + (!c && extra ? "  " + JSON.stringify(extra).slice(0, 2500) : "")); if (!c) fail++; };
// ---- mock upstream services ----
let lastSys = "";
const mock = http.createServer((req, res) => { let s = ""; req.on("data", c => s += c); req.on("end", () => {
  const u = new URL(req.url, "http://x"), j = o => { res.writeHead(200, { "Content-Type": "application/json" }); res.end(JSON.stringify(o)); };
  if (u.pathname === "/v1/search") return j({ results: [{ name: "Dhaka", admin1: "Dhaka", country: "Bangladesh", latitude: 23.7, longitude: 90.4 }] });
  if (u.pathname === "/v1/forecast") return j({ current: { temperature_2m: 29.4, relative_humidity_2m: 70, apparent_temperature: 33, weather_code: 2, wind_speed_10m: 11 }, daily: { time: ["2026-11-06", "2026-11-07", "2026-11-08"], weather_code: [2, 3, 61], temperature_2m_max: [31, 30, 29], temperature_2m_min: [24, 23, 23], precipitation_probability_max: [10, 20, 60] }, timezone: "Asia/Dhaka" });
  if (u.pathname === "/res/v1/web/search") return j({ web: { results: [{ title: "Pizza guide", url: "https://a.example/p", description: "Best pizza" }] } });
  if (u.pathname === "/chat/completions") { lastSys = JSON.parse(s).messages[0].content; res.writeHead(200, { "Content-Type": "text/event-stream" }); for (const t of ["Sure, ", "done."]) res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: t } }] })}\n\n`); return res.end("data: [DONE]\n\n"); }
  res.writeHead(404); res.end(); }); });
await new Promise(r => mock.listen(4801, r)); await new Promise(r => server.listen(4800, r));
Object.assign(process.env, { GEO_BASE: "http://localhost:4801", WEATHER_BASE: "http://localhost:4801", SEARCH_BASE: "http://localhost:4801", OPENAI_BASE_URL: "http://localhost:4801", OPENAI_API_KEY: "k", BRAVE_API_KEY: "b", ACCESS_CODE: "", RATE_PER_MIN: "1000", TOOL_RATE_PER_MIN: "1000", DAILY_LIMIT: "5000" });
const U = "http://localhost:4800/";
const browser = await chromium.launch({ channel: "chromium" });
const errors = [];
const watch = p => { p.on("pageerror", e => errors.push("pageerror: " + e)); p.on("console", m => { if (m.type() === "error" && !/Failed to load resource|fonts\.g|ERR_/.test(m.text())) errors.push("console: " + m.text()); }); p.on("dialog", d => d.dismiss().catch(() => {})); };
// fake speech APIs, installed before the app loads
const FAKE = () => {
  window.__spoken = []; window.__srs = [];
  class SR { constructor() { this.lang = ""; this.continuous = false; window.__srs.push(this); } start() { this.on = true; setTimeout(() => this.onstart && this.onstart(), 10); } abort() { this.on = false; } stop() { this.abort(); this.onend && this.onend(); }
    emit(t) { if (!this.on) return; this.onresult && this.onresult({ resultIndex: 0, results: [Object.assign([{ transcript: t }], { isFinal: true })] }); if (!this.continuous) { this.on = false; setTimeout(() => this.onend && this.onend(), 10); } } }
  window.SpeechRecognition = SR; window.webkitSpeechRecognition = SR;
  const ss = { speak(u) { window.__spoken.push({ text: u.text, lang: u.lang, rate: u.rate }); setTimeout(() => { u.onstart && u.onstart(); u.onend && u.onend(); }, 10); }, cancel() {}, getVoices() { return [{ lang: "en-US", name: "Test EN" }, { lang: "bn-BD", name: "Test BN" }]; }, onvoiceschanged: null };
  Object.defineProperty(window, "speechSynthesis", { value: ss, configurable: true });
  window.SpeechSynthesisUtterance = function (t) { this.text = t; };
};
const mk = async (w = 390, h = 844, opts = {}) => { const c = await browser.newContext({ viewport: { width: w, height: h }, permissions: ["clipboard-read", "clipboard-write", "geolocation"], ...opts }); await c.route(u => !/^(localhost|127\.0\.0\.1)$/.test(u.hostname) && !/fonts\.g/.test(u.hostname), r => r.fulfill({ status: 200, contentType: "text/html", body: "<p>external</p>" })); const p = await c.newPage(); watch(p); return [c, p]; };
const wait = (p, ms = 250) => p.waitForTimeout(ms);
const jsclick = (p, sel) => p.evaluate(s => { const e = document.querySelector(s); if (!e) throw new Error("missing " + s); e.click(); }, sel);
const txt = (p, sel) => p.evaluate(s => (document.querySelector(s) || {}).textContent || "", sel);
const chatSay = async (p, t) => { await p.evaluate(() => go("chat")); await p.fill("#cin", t); await jsclick(p, "#send"); await wait(p, 400); };
const lastMsg = p => p.evaluate(() => { const m = document.querySelectorAll("#msgs .m"); return m.length ? m[m.length - 1].textContent : ""; });
const TOOLS = ["calc", "unit", "time", "weather", "rem", "cal", "trans", "sum", "search", "browser"];

// ================= 1. NAVIGATION =================
let [ctx, page] = await mk(); await ctx.addInitScript(FAKE); await page.goto(U); await wait(page, 500);
const navs = await page.$$eval("nav button", b => b.map(x => x.dataset.go));
ok("bottom navigation has 5 items", navs.join() === "home,chat,voice,tools,settings", navs);
for (const g of navs) { await page.click(`nav button[data-go="${g}"]`); await wait(page, 120); ok(`nav → ${g} opens and is highlighted`, await page.evaluate(g => document.getElementById(g).classList.contains("on") && document.querySelector(`nav button[data-go="${g}"]`).classList.contains("on"), g)); }
const goTargets = await page.$$eval("[data-go]", e => [...new Set(e.map(x => x.dataset.go))]);
for (const g of goTargets) { await page.evaluate(g => go(g), g); ok(`screen "${g}" exists and shows`, await page.evaluate(g => { const e = document.getElementById(g); return !!e && e.classList.contains("on"); }, g)); }
await page.evaluate(() => go("home")); await page.click('nav button[data-go="tools"]');
for (const t of TOOLS) { await jsclick(page, `[data-tool="${t}"]`); await wait(page, 150); ok(`tool "${t}" opens with a title`, await page.evaluate(() => document.getElementById("tool").classList.contains("on") && document.getElementById("ttl").textContent.length > 2)); await page.evaluate(() => go("tools")); }
ok("tools list has all 10 tools + tasks, notes, apps", (await page.$$eval("#tools [data-tool],#tools [data-go]", e => e.length)) >= 13);

// ================= 2. PRESS EVERY BUTTON =================
const SKIP = new Set(["lockbtn", "wipe", "clrc", "dchats", "dtn", "drc", "storp", "notbtn", "instbtn"]);
let pressed = 0; const screens = ["home", "chat", "voice", "tools", "tasks", "notes", "apps", "about", "settings"];
const press = async label => { const ids = await page.$$eval("main button, main select, main input[type=checkbox], main input[type=range]", els => els.filter(e => e.offsetParent !== null).map((e, i) => { e.setAttribute("data-qa", i); return { i, id: e.id, tag: e.tagName, type: e.type }; })); for (const e of ids) { if (SKIP.has(e.id)) continue; try { await page.evaluate(i => { const el = document.querySelector(`[data-qa="${i}"]`); if (!el) return; if (el.tagName === "SELECT") { if (el.options.length > 1) { el.selectedIndex = (el.selectedIndex + 1) % el.options.length; el.dispatchEvent(new Event("change", { bubbles: true })); el.dispatchEvent(new Event("input", { bubbles: true })); } } else if (el.type === "range") { el.value = el.min; el.dispatchEvent(new Event("input", { bubbles: true })); } else el.click(); }, e.i); pressed++; } catch (err) { errors.push(label + ": " + err.message); } await page.waitForTimeout(15); } };
for (const s of screens) { await page.evaluate(s => go(s), s); await wait(page, 100); await press(s); }
for (const t of TOOLS) { await page.evaluate(t => openTool(t), t); await wait(page, 150); await press("tool:" + t); }
ok(`pressed ${pressed} buttons/selects/sliders across all screens without a crash`, pressed > 100 && errors.length === 0, errors.slice(0, 5));
await ctx.close();

// ================= 3. FEATURES =================
[ctx, page] = await mk(); await ctx.addInitScript(FAKE); await page.goto(U); await wait(page, 500);
// tasks & notes
await page.evaluate(() => go("tasks")); await page.fill("#tin", "Buy bread"); await jsclick(page, "#tadd"); await wait(page, 100);
await page.evaluate(() => document.querySelector('#tlist input[type=checkbox]').click()); await wait(page, 100);
ok("task add + tick off", /Buy bread/.test(await txt(page, "#tlist")) && await page.evaluate(() => tasks.some(t => /Buy bread/.test(t.x) && t.d === true)));
await page.evaluate(() => go("notes")); await page.fill("#nin", "Remember the milk"); await jsclick(page, "#nadd"); await wait(page, 100);
ok("note add", /Remember the milk/.test(await txt(page, "#nlist")));
// calculator
await page.evaluate(() => openTool("calc")); await page.fill("#cex", "12*(3+4)"); await wait(page, 100);
ok("calculator live preview = 84", /84/.test(await txt(page, "#cres")));
await page.fill("#cex", ""); for (const k of ["7", "×", "6", "="]) await jsclick(page, `#ckeys [data-k="${k}"]`); await wait(page, 100);
ok("calculator keypad 7×6 = 42", (await page.inputValue("#cex")).includes("42"), await page.inputValue("#cex"));
await page.fill("#cex", "1/0"); await jsclick(page, '#ckeys [data-k="="]'); await wait(page, 100);
ok("calculator handles divide by zero without crashing", !(await page.inputValue("#cex")).includes("Infinity") && errors.length === 0);
// unit converter
await page.evaluate(() => openTool("unit")); await page.selectOption("#ucat", "length"); await page.fill("#uv", "5"); await page.selectOption("#uf", "km"); await page.selectOption("#ut", "mi"); await wait(page, 100);
ok("unit converter 5 km = 3.107 mi", /3\.10/.test(await txt(page, "#ur")), await txt(page, "#ur"));
// time
await page.evaluate(() => openTool("time")); await wait(page, 300); ok("time tool shows clock + world clocks", /\d/.test(await txt(page, "#tc")) && (await page.evaluate(() => document.getElementById("tbody").textContent)).includes("Tokyo"));
// weather
await page.evaluate(() => openTool("weather")); await page.fill("#wc", "Dhaka"); await jsclick(page, "#wgo"); await wait(page, 700);
ok("weather shows Dhaka forecast", /Dhaka/.test(await txt(page, "#wr")) && /29/.test(await txt(page, "#wr")), await txt(page, "#wr"));
// web search
await page.evaluate(() => openTool("search")); await page.fill("#sq", "pizza"); await jsclick(page, "#sgo2"); await wait(page, 700);
ok("web search shows results", /Pizza guide/.test(await txt(page, "#sres")), (await txt(page, "#sres")).slice(0, 200));
// translate + summarize
await page.evaluate(() => openTool("trans")); await page.fill("#tx", "Hello"); await jsclick(page, "#tg"); await wait(page, 800);
ok("translate returns the AI text", /Sure, done\./.test(await txt(page, "#to")), (await txt(page, "#to")).slice(0, 200));
ok("translate sends a translator prompt", /translat/i.test(lastSys), lastSys.slice(0, 100));
await page.evaluate(() => openTool("sum")); await page.fill("#sx", "A long text to summarise."); await jsclick(page, "#sg"); await wait(page, 800);
ok("summarizer returns the AI text", /Sure, done\./.test(await txt(page, "#so")));
// calendar
await page.evaluate(() => openTool("cal")); await wait(page, 150);
ok("calendar renders a month grid", (await page.$$eval("#cg button, #cg div", e => e.length)) >= 28);
await page.fill("#cet", "Dentist"); await jsclick(page, "#cea"); await wait(page, 200);
ok("calendar adds an event for the selected day", /Dentist/.test(await txt(page, "#cel")), await txt(page, "#cel"));
await page.evaluate(() => openTool("browser")); await page.fill("#bu", "example.com"); const bp = page.context().waitForEvent("page", { timeout: 4000 }).catch(() => null); await jsclick(page, "#bgo"); const bpg = await bp; ok("browser tool opens the site", !!bpg && /example\.com/.test(bpg.url()), bpg && bpg.url()); if (bpg) await bpg.close().catch(() => {});
ok("browser tool lists quick links", (await page.$$eval("#bl .row", e => e.length)) >= 5);
// reminders (fake clock)
await page.close(); await ctx.close();
[ctx, page] = await mk(); await ctx.addInitScript(FAKE); await page.clock.install({ time: new Date("2026-11-08T10:00:00") }); await page.goto(U); await wait(page, 500);
await chatSay(page, "remind me to drink water in 1 minute"); ok("reminder command accepted", /remind you/i.test(await lastMsg(page)), await lastMsg(page));
await page.clock.fastForward("01:30"); await wait(page, 300);
ok("reminder fires on time (alert shown)", /Reminder: Drink water/i.test(await txt(page, "#toast")), await txt(page, "#toast"));
await ctx.close();

// ================= 4. COMMANDS & APP LAUNCHING =================
[ctx, page] = await mk(); await ctx.addInitScript(FAKE); await page.goto(U); await wait(page, 500);
const popup = async fn => { const pr = page.context().waitForEvent("page", { timeout: 4000 }).catch(() => null); await fn(); const np = await pr; if (!np) return ""; const u = np.url(); await np.close().catch(() => {}); return u; };
let u1 = await popup(() => chatSay(page, "open youtube")); ok("'open youtube' launches YouTube", /youtube\.com/.test(u1) || /youtube/i.test(await lastMsg(page)), [u1, await lastMsg(page)]);
u1 = await popup(() => chatSay(page, "search for pizza near me")); ok("'search for …' opens a web search", /google\.com\/search\?q=pizza/.test(u1), u1);
u1 = await popup(() => chatSay(page, "navigate to Dhaka airport")); ok("'navigate to …' opens Maps", /google\.com\/maps/.test(u1), u1);
u1 = await popup(() => chatSay(page, "open example.com")); ok("'open example.com' opens that site", /example\.com/.test(u1), u1);
await chatSay(page, "open snapchat"); ok("unknown app gets an honest answer", /don't have|not in/i.test(await lastMsg(page)), await lastMsg(page));
await chatSay(page, "open settings"); ok("phone settings: honest 'not possible in a web app'", /can't open phone settings/i.test(await lastMsg(page)));
await chatSay(page, "copy hello world"); ok("'copy …' reports the real result", /Copied|blocked/i.test(await lastMsg(page)));
ok("clipboard really contains the text", (await page.evaluate(() => navigator.clipboard.readText().catch(() => ""))) === "hello world");
await chatSay(page, "call 01712345678"); ok("'call …' asks for confirmation first", await page.evaluate(() => [...document.querySelectorAll("#msgs button")].some(b => b.textContent === "Confirm")));
await chatSay(page, "cancel"); ok("saying 'cancel' cancels the call", /Cancelled/.test(await lastMsg(page)));
await chatSay(page, "email test@example.com"); ok("'email …' asks for confirmation", await page.evaluate(() => [...document.querySelectorAll("#msgs button")].some(b => b.textContent === "Confirm")));
await chatSay(page, "no");
await chatSay(page, "what time is it"); ok("'what time is it' answered locally", /\d{1,2}:\d{2}/.test(await lastMsg(page)));
await chatSay(page, "calculate 15% of 200"); ok("'calculate 15% of 200' = 30", /30/.test(await lastMsg(page)), await lastMsg(page));
await chatSay(page, "convert 100 c to f"); ok("'convert 100 c to f' = 212", /212/.test(await lastMsg(page)), await lastMsg(page));
await chatSay(page, "weather in Dhaka"); ok("'weather in Dhaka' answers with the forecast", /Dhaka/.test(await lastMsg(page)) && /29/.test(await lastMsg(page)), await lastMsg(page));
await chatSay(page, "add task renew passport"); await chatSay(page, "note call the bank"); ok("task/note commands work", await page.evaluate(() => tasks.some(t => /passport/i.test(t.x)) && notes.some(n => /bank/i.test(typeof n === "string" ? n : n.x || n.t || JSON.stringify(n)))));
await chatSay(page, "Tell me a joke"); ok("normal chat goes to the AI and streams a reply", /Sure, done\./.test(await lastMsg(page)));
ok("AI request carries the assistant instructions", /JARVIS|assistant/i.test(lastSys));
await ctx.close();

// ================= 5. VOICE (faked microphone and speaker) =================
[ctx, page] = await mk(); await ctx.addInitScript(FAKE); await page.goto(U); await wait(page, 500);
await page.evaluate(() => go("voice")); await jsclick(page, "#mic"); await wait(page, 100);
ok("mic starts listening (animation + status)", await page.evaluate(() => /Listening/.test(document.getElementById("vstat").textContent) && document.getElementById("core2").classList.contains("listen")));
await page.evaluate(() => __srs.at(-1).emit("add task buy rice")); await wait(page, 300);
ok("voice command adds a task", await page.evaluate(() => tasks.some(t => /buy rice/i.test(t.x))));
ok("voice answer is spoken", await page.evaluate(() => __spoken.some(s => /Task added/i.test(s.text))));
await jsclick(page, "#mic"); await wait(page, 100); await page.evaluate(() => __srs.at(-1).emit("Tell me something")); await wait(page, 700);
ok("voice → AI reply shown and spoken", /Sure, done\./.test(await txt(page, "#vans")) && await page.evaluate(() => __spoken.some(s => /Sure, done/.test(s.text))));
await page.evaluate(() => { ST.voice = false; save(); apply(); }); const n0 = await page.evaluate(() => __spoken.length); await jsclick(page, "#mic"); await wait(page, 100); await page.evaluate(() => __srs.at(-1).emit("Tell me more")); await wait(page, 700);
ok("voice replies toggle off = no speech", (await page.evaluate(() => __spoken.length)) === n0);
await page.evaluate(() => { ST.voice = true; ST.lang = "bn"; save(); apply(); }); await jsclick(page, "#mic"); await wait(page, 100);
ok("Bangla mode listens in bn-BD", await page.evaluate(() => __srs.at(-1).lang === "bn-BD"));
await page.evaluate(() => { __srs.at(-1).emit("stop"); ST.lang = "en"; ST.wake = true; save(); apply(); go("home"); go("voice"); }); await wait(page, 300);
ok("wake word starts continuous listening on the Voice screen", await page.evaluate(() => { const s = __srs.at(-1); return s.continuous === true && s.on; }));
await page.evaluate(() => __srs.at(-1).emit("jarvis add task wake word works")); await wait(page, 400);
ok("wake word + command runs", await page.evaluate(() => tasks.some(t => /wake word works/i.test(t.x))));
await page.evaluate(() => go("home")); await wait(page, 150); ok("wake listening stops when leaving the Voice screen", await page.evaluate(() => !__srs.at(-1).on));
await ctx.close();

// ================= 6. SETTINGS, THEMES, LANGUAGE, PIN =================
[ctx, page] = await mk(); await page.goto(U); await wait(page, 500);
await page.evaluate(() => { ST.name = "Friday"; ST.greet = "ready when you are"; save(); apply(); go("home"); }); await wait(page, 150);
ok("custom assistant name and greeting appear", /Friday/.test(await txt(page, "header")) && /ready when you are/.test(await txt(page, "#greet")));
for (const th of ["light", "dark", "auto"]) { await page.evaluate(t => { ST.theme = t; save(); apply(); }, th); await wait(page, 100); ok(`theme ${th} applies`, await page.evaluate(() => ["light", "dark"].includes(document.documentElement.dataset.theme))); }
await page.evaluate(() => { ST.lang = "bn"; save(); apply(); go("home"); }); await wait(page, 300);
ok("Bangla interface changes the main labels", /[\u0980-\u09FF]/.test(await txt(page, "nav")));
await page.evaluate(() => { ST.lang = "en"; save(); apply(); }); await wait(page, 200);
await page.evaluate(() => go("settings")); await jsclick(page, "#lockbtn"); await wait(page, 300);
const pinType = async d => { await page.fill("#lpin", d); await jsclick(page, "#lok"); await wait(page, 400); };
await pinType("4821"); await pinType("4821"); await wait(page, 300);
ok("PIN lock can be turned on", /On/.test(await txt(page, "#lockst")), await txt(page, "#lockst"));
await page.reload(); await wait(page, 700);
ok("app asks for the PIN after reload", await page.evaluate(() => getComputedStyle(document.getElementById("lock")).display !== "none"));
await pinType("1111"); ok("wrong PIN is refused", await page.evaluate(() => getComputedStyle(document.getElementById("lock")).display !== "none"));
await pinType("4821"); ok("right PIN unlocks", await page.evaluate(() => getComputedStyle(document.getElementById("lock")).display === "none"));
await ctx.close();

// ================= 7. RESPONSIVE LAYOUT, TAP TARGETS, CONTRAST, ACCESSIBILITY =================
const sizes = [[320, 568], [360, 740], [390, 844], [412, 915], [768, 1024], [1280, 800]];
const overflow = [], small = new Set(), lowc = new Set(), unnamed = new Set();
for (const theme of ["dark", "light"]) for (const [w, h] of sizes) {
  [ctx, page] = await mk(w, h); await page.addInitScript(t => localStorage.setItem("jv", JSON.stringify({ theme: t })), theme); await page.goto(U); await wait(page, 450);
  await page.evaluate(() => { tasks.push({ x: "A very long task title that should wrap nicely on a narrow phone screen without overflowing", d: false }); rT(); });
  const views = [...screens.map(s => ["s", s]), ...TOOLS.map(t => ["t", t])];
  for (const [k, id] of views) {
    await page.evaluate(([k, id]) => k === "s" ? go(id) : openTool(id), [k, id]); await wait(page, 120);
    const r = await page.evaluate(() => { const m = document.querySelector("main"), vis = e => e.offsetParent !== null;
      const lum = c => { const a = c.match(/[\d.]+/g).map(Number); const f = v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(a[0]) + .7152 * f(a[1]) + .0722 * f(a[2]); };
      const bg = el => { for (let e = el; e; e = e.parentElement) { const c = getComputedStyle(e).backgroundColor; const a = c.match(/[\d.]+/g); if (a && (a.length < 4 || +a[3] > .5)) return c; } return "rgb(10,14,21)"; };
      const out = { ov: document.documentElement.scrollWidth > innerWidth + 1 || m.scrollWidth > m.clientWidth + 1, small: [], low: [], un: [] };
      m.querySelectorAll("button,select,input:not([type=checkbox]):not([type=range]),textarea,a").forEach(e => { if (!vis(e)) return; const b = e.getBoundingClientRect(); if (b.height < 36 || b.width < 36 && e.tagName === "BUTTON" && !e.textContent.trim()) out.small.push((e.id || e.className || e.tagName) + ":" + Math.round(b.width) + "x" + Math.round(b.height) + ":" + (e.textContent || "").trim().slice(0, 12)); if (e.tagName === "BUTTON" && !(e.textContent || "").replace(/[✕›‹↑→+⌫·\s]/g, "").length && !e.getAttribute("aria-label") && !e.title) out.un.push(e.id || e.dataset.del || e.dataset.rd || e.textContent); });
      m.querySelectorAll("*").forEach(e => { if (!vis(e) || ![...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim().length > 1)) return; const cs = getComputedStyle(e); const f = lum(cs.color), g = lum(bg(e)), cr = (Math.max(f, g) + .05) / (Math.min(f, g) + .05); if (cr < 3.5 && +cs.opacity > .5) out.low.push(e.textContent.trim().slice(0, 24) + " " + cr.toFixed(1)); });
      return out; });
    if (r.ov) overflow.push(`${theme} ${w}px ${id}`); r.small.forEach(s => small.add(id + ":" + s)); r.low.forEach(s => lowc.add(`${theme} ${id}: ${s}`)); r.un.forEach(s => unnamed.add(id + ":" + s));
  }
  await ctx.close();
}
ok("no horizontal overflow on any screen/tool at 320–1280px, dark and light", overflow.length === 0, overflow.slice(0, 10));
ok("no low-contrast text (below 3.5:1) in dark or light theme", lowc.size === 0, [...lowc].slice(0, 12));
ok("icon-only buttons have an accessible name", unnamed.size === 0, [...unnamed].slice(0, 10));
const smallList = [...small]; notes.push("controls under 36px high: " + smallList.length); ok("all tap targets are at least 36px high", smallList.length === 0, smallList.slice(0, 80));
ok("no JavaScript errors anywhere in the whole run", errors.length === 0, errors.slice(0, 6));
await browser.close(); server.close(); mock.close(); notes.forEach(n => console.log("NOTE " + n)); console.log(fail ? fail + " FAILED" : "ALL PASSED"); process.exit(fail ? 1 : 0);
