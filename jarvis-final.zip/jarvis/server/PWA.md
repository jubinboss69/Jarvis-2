# Installing JARVIS on Android

## Requirements
- The app must be opened from an **https** address (Render, Railway, or any host with a certificate). `http://localhost` also works for testing. Plain http on a phone cannot be installed.
- Use **Chrome on Android**.

## Install
1. Open your JARVIS address in Chrome and send one message so the page is fully loaded.
2. Chrome may show an install banner, or JARVIS shows its own **Install** card on Home. Tap it.
3. Otherwise: Chrome menu (three dots) > **Install app** (or **Add to Home screen**).
4. Open JARVIS from the new home-screen icon. It runs full-screen without the browser bar.
5. In **Settings > App**, tap **Notifications** and allow them. In **Settings > Storage**, tap **Protect from automatic clearing**.

## What the installed web app can do
Full-screen window, home-screen icon, long-press shortcuts (Chat, Voice, Tasks), sharing text from other apps into JARVIS, opening offline (tasks, notes, calendar, calculator, converter, time, saved chats), reminder notifications while the app is running, voice and wake word while the app is open.

## What it cannot do (needs a native Android app, see NATIVE_LAYER.md)
Wake word with the screen off or the app closed, opening phone settings or any installed app by name, reminders that ring reliably when the app is closed (Android pauses web apps; export important ones to your calendar), reading contacts or SMS, switching Wi-Fi or Bluetooth.

## Updates
The service worker names its cache after a hash of the app files, so every new deploy is picked up automatically. JARVIS shows "JARVIS was updated. Reload" when that happens. Settings > About > Check for update forces a check.

## Offline behavior
The app shell is cached. Chat, weather, search, translate and summarize need internet and say so. Your data lives on the phone, so it is available offline. API requests are never cached.
