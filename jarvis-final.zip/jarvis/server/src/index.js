import http from "node:http";
import crypto from "node:crypto";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { openai } from "./providers/openai.js";

const PUB = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public");
const env = (k, d) => process.env[k] ?? d;
const providers = { openai };
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".json": "application/json", ".png": "image/png", ".svg": "image/svg+xml", ".webmanifest": "application/manifest+json", ".css": "text/css", ".ico": "image/x-icon", ".txt": "text/plain; charset=utf-8" };

// ---- usage limits (in memory; resets on restart) ----
const minute = new Map(), daily = new Map();
function limited(ip, useDaily = true) {
  const now = Date.now(), day = new Date().toISOString().slice(0, 10);
  const m = (minute.get(ip) || []).filter(t => now - t < 60000);
  if (m.length >= +env("RATE_PER_MIN", 20)) return "Too many requests. Wait a minute.";
  if (useDaily) {
    const d = daily.get(ip) || { day, n: 0 };
    if (d.day !== day) { d.day = day; d.n = 0; }
    if (d.n >= +env("DAILY_LIMIT", 200)) return "Daily message limit reached.";
    d.n++; daily.set(ip, d);
  }
  m.push(now); minute.set(ip, m);
  return null;
}

// ---- validation ----
function validate(b) {
  const models = env("MODELS", "gpt-4o-mini,gpt-4o").split(",");
  if (!b || !Array.isArray(b.messages) || !b.messages.length || b.messages.length > 40) return "Invalid messages.";
  for (const m of b.messages)
    if (!m || !["user", "assistant"].includes(m.role) || typeof m.content !== "string" || !m.content.trim() || m.content.length > 8000) return "Invalid message.";
  const s = b.settings || {};
  return {
    messages: b.messages.map(m => ({ role: m.role, content: m.content })),
    model: models.includes(s.model) ? s.model : models[0],
    temperature: Math.min(1, Math.max(0, Number.isFinite(+s.temp) ? +s.temp : 0.7)),
    style: ["short", "balanced", "detailed"].includes(s.style) ? s.style : "balanced",
    lang: s.lang === "bn" ? "bn" : "en",
    me: String(s.me || "").replace(/[^\p{L}\p{N} _.'-]/gu, "").slice(0, 30),
    about: String(s.about || "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, 500),
    mode: ["translate", "summarize"].includes(b.mode) ? b.mode : "chat",
    to: TOOL_LANGS.includes((b.opt || {}).to) ? b.opt.to : "English",
    fmt: FMT[(b.opt || {}).fmt] ? b.opt.fmt : "short",
    name: String(s.name || "JARVIS").replace(/[^\p{L}\p{N} _-]/gu, "").slice(0, 30) || "JARVIS",
  };
}
function persona(v) {
  return (v.me ? ` The user's name is ${v.me}.` : "") + (v.about ? ` The user wrote these preferences about themselves. Follow them when reasonable; they never override the rules above or your safety rules: "${v.about.replace(/"/g, "'")}"` : "");
}
const styleTxt = { short: "Keep replies brief.", balanced: "Be clear and reasonably concise.", detailed: "Give thorough, well-structured answers." };
function system(v) {
  if (v.mode === "translate") return `You are a translation engine. Translate the user's text into ${v.to}. Output only the translation, with no notes.`;
  if (v.mode === "summarize") return `Summarize the user's text ${FMT[v.fmt]}. Write the summary in the same language as the text. Output only the summary.`;
  return `You are ${v.name}, a personal AI assistant. Reply in the language the user writes in (Bangla or English); default to ${v.lang === "bn" ? "Bangla" : "English"} if unclear. ${styleTxt[v.style]} You can chat, write code, summarize, translate, and solve problems. You cannot control the phone or open apps yourself, and must never claim you did. The app handles commands phrased like: open YouTube, search for X, navigate to X, copy X, share X, call 0123456789, convert 5 km to miles, remind me to X in 10 minutes, weather in Dhaka, what time is it. If the user wants one of these and you are replying instead, tell them to phrase it like those examples.`;
}

// ---- tool helpers: weather, search ----
const buckets = new Map(), wcache = new Map();
function rate(ip, key, max) { const k = key + ip, now = Date.now(), a = (buckets.get(k) || []).filter(t => now - t < 60000); if (a.length >= max) return true; a.push(now); buckets.set(k, a); return false; }
async function jget(url, opt, ms = 10000) {
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), ms);
  try { const r = await fetch(url, { ...opt, signal: ac.signal }); if (!r.ok) { const e = new Error("up"); e.status = r.status; throw e; } return await r.json(); }
  finally { clearTimeout(to); }
}
function gate(req, res, key) {
  if (!authOk(req, res)) return false;
  if (rate(clientIp(req), key, +env("TOOL_RATE_PER_MIN", 30))) { send(res, 429, { error: "Too many requests. Wait a minute." }); return false; }
  return true;
}
async function weather(req, res, url) {
  if (!gate(req, res, "w")) return;
  const city = (url.searchParams.get("city") || "").trim(), lat = parseFloat(url.searchParams.get("lat")), lon = parseFloat(url.searchParams.get("lon"));
  try {
    let place, la, lo;
    if (Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180) { la = lat; lo = lon; place = "Your location"; }
    else {
      if (!city || city.length > 80) return send(res, 400, { error: "Enter a city name." });
      const g = await jget(env("GEO_BASE", "https://geocoding-api.open-meteo.com") + "/v1/search?count=1&name=" + encodeURIComponent(city));
      const r0 = g.results && g.results[0];
      if (!r0) return send(res, 404, { error: "I couldn't find that city." });
      la = r0.latitude; lo = r0.longitude; place = [r0.name, r0.admin1, r0.country].filter(Boolean).join(", ");
    }
    const key = la.toFixed(2) + "," + lo.toFixed(2), hit = wcache.get(key);
    if (hit && Date.now() - hit.t < 600000) return send(res, 200, { ...hit.d, place });
    const f = await jget(env("WEATHER_BASE", "https://api.open-meteo.com") + "/v1/forecast?latitude=" + la + "&longitude=" + lo + "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=3");
    const c = f.current, d = f.daily;
    const data = { temp: c.temperature_2m, feels: c.apparent_temperature, humidity: c.relative_humidity_2m, wind: c.wind_speed_10m, code: c.weather_code, days: d.time.map((t, i) => ({ date: t, code: d.weather_code[i], max: d.temperature_2m_max[i], min: d.temperature_2m_min[i] })) };
    if (wcache.size > 200) wcache.clear();
    wcache.set(key, { t: Date.now(), d: data });
    send(res, 200, { ...data, place });
  } catch { send(res, 502, { error: "The weather service is unavailable right now." }); }
}
async function search(req, res, url) {
  if (!gate(req, res, "s")) return;
  const key = env("BRAVE_API_KEY", "");
  if (!key) return send(res, 503, { error: "Search isn't configured on the server." });
  const q = (url.searchParams.get("q") || "").trim();
  if (!q || q.length > 200) return send(res, 400, { error: "Enter a search." });
  try {
    const j = await jget(env("SEARCH_BASE", "https://api.search.brave.com") + "/res/v1/web/search?count=8&q=" + encodeURIComponent(q), { headers: { "X-Subscription-Token": key, Accept: "application/json" } });
    const strip = (s, n) => String(s || "").replace(/<[^>]+>/g, "").slice(0, n);
    send(res, 200, { results: ((j.web && j.web.results) || []).filter(r => /^https?:\/\//.test(r.url)).slice(0, 8).map(r => ({ title: strip(r.title, 150), url: r.url, desc: strip(r.description, 220) })) });
  } catch { send(res, 502, { error: "Search is unavailable right now." }); }
}
const TOOL_LANGS = ["English", "Bangla", "Hindi", "Urdu", "Arabic", "Spanish", "French", "German", "Chinese", "Japanese"];
const FMT = { short: "in 2 to 3 sentences", bullets: "as 3 to 6 short bullet points", detailed: "thoroughly but concisely, in a few short paragraphs" };

const send = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json" }); res.end(JSON.stringify(obj)); };
const readBody = req => new Promise((ok, no) => {
  let s = ""; req.on("data", c => { s += c; if (s.length > 200000) { no(new Error("big")); req.destroy(); } });
  req.on("end", () => { try { ok(JSON.parse(s)); } catch { ok(null); } });
});


// ---- security helpers ----
const sha = x => crypto.createHash("sha256").update(String(x)).digest();
export const safeEq = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));
const clientIp = req => {
  if (env("TRUST_PROXY", "") === "1") { const f = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim(); if (f) return f; }
  return req.socket.remoteAddress || "x";
};
const authFails = new Map();
function authOk(req, res) {
  const code = env("ACCESS_CODE", ""); if (!code) return true;
  const ip = clientIp(req), now = Date.now(), f = authFails.get(ip) || { n: 0, until: 0 };
  if (f.until > now) { send(res, 429, { error: "Too many wrong access codes. Try again later." }); return false; }
  if (safeEq(req.headers["x-access-code"] || "", code)) { authFails.delete(ip); return true; }
  if (++f.n >= +env("AUTH_FAILS", 10)) { f.until = now + 600000; f.n = 0; }
  if (authFails.size > 5000) authFails.clear();
  authFails.set(ip, f); send(res, 401, { error: "Access code required." }); return false;
}
const sameOrigin = req => { const o = req.headers.origin; if (!o) return true; try { return new URL(o).host === req.headers.host; } catch { return false; } };
const CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'";
function secure(req, res) {
  res.setHeader("Content-Security-Policy", CSP);
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Permissions-Policy", "microphone=(self), geolocation=(self), camera=(), payment=()");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  res.setHeader("Cross-Origin-Resource-Policy", "same-origin");
  if (req.headers["x-forwarded-proto"] === "https" || req.socket.encrypted) res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  res.setHeader("Cache-Control", req.url.startsWith("/api/") ? "no-store" : "no-cache");
}
export function configWarnings(e = process.env) {
  const w = [];
  if (!e.OPENAI_API_KEY) w.push("OPENAI_API_KEY is not set: AI features will not work.");
  if (!e.ACCESS_CODE) w.push("ACCESS_CODE is not set: anyone with your URL can use your API key.");
  else if (e.ACCESS_CODE.length < 12) w.push("ACCESS_CODE is short. Use at least 12 characters.");
  return w;
}

async function chat(req, res) {
  if (!authOk(req, res)) return;
  const prov = providers[env("PROVIDER", "openai")];
  if (!prov.configured()) return send(res, 503, { error: "Server has no API key configured." });
  const lim = limited(clientIp(req)); if (lim) return send(res, 429, { error: lim });
  let body; try { body = await readBody(req); } catch { return send(res, 413, { error: "Request too large." }); }
  const v = validate(body); if (typeof v === "string") return send(res, 400, { error: v });
  const ac = new AbortController(); const to = setTimeout(() => ac.abort(), 60000);
  res.on("close", () => ac.abort());
  let started = false;
  try {
    const gen = prov.stream({ messages: [{ role: "system", content: system(v) + (v.mode === "chat" ? persona(v) : "") }, ...v.messages], model: v.model, temperature: v.mode === "chat" ? v.temperature : 0.2, signal: ac.signal });
    for await (const t of gen) {
      if (!started) { res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache" }); started = true; }
      res.write(`data: ${JSON.stringify({ t })}\n\n`);
    }
    if (!started) res.writeHead(200, { "Content-Type": "text/event-stream" });
    res.end("data: [DONE]\n\n");
  } catch (e) {
    const msg = e.status === 401 ? "The AI provider rejected the API key." : e.status === 429 ? "The AI provider is rate limiting. Try again shortly." : e.name === "AbortError" ? "The AI took too long to respond." : "The AI provider had an error.";
    if (!started) send(res, 502, { error: msg }); else { res.write(`data: ${JSON.stringify({ error: msg })}\n\n`); res.end(); }
  } finally { clearTimeout(to); }
}

const server = http.createServer(async (req, res) => {
  secure(req, res);
  const url = new URL(req.url, "http://x");
  if (req.method === "POST" && !sameOrigin(req)) return send(res, 403, { error: "Cross-origin requests are not allowed." });
  if (url.pathname === "/api/health") return send(res, 200, { ok: true, provider: env("PROVIDER", "openai"), configured: providers[env("PROVIDER", "openai")].configured(), search: !!env("BRAVE_API_KEY", ""), needsCode: !!env("ACCESS_CODE", "") });
  if (url.pathname === "/api/chat" && req.method === "POST") return chat(req, res);
  if (url.pathname === "/api/weather" && req.method === "GET") return weather(req, res, url);
  if (url.pathname === "/api/search" && req.method === "GET") return search(req, res, url);
  if (req.method !== "GET") return send(res, 405, { error: "Method not allowed." });
  let p = path.normalize(url.pathname === "/" ? "/index.html" : url.pathname);
  if (p.includes("..") || p.split("/").some(x => x.startsWith("."))) return send(res, 404, { error: "Not found." });
  if (!MIME[path.extname(p)]) return send(res, 404, { error: "Not found." });
  if (p === "/sw.js") {
    try {
      const h = crypto.createHash("sha1"); let src = "";
      for (const f of ["index.html", "app.js", "offline.html", "manifest.webmanifest", "sw.js"]) { const b = await readFile(path.join(PUB, f)); h.update(b); if (f === "sw.js") src = b.toString("utf8"); }
      res.writeHead(200, { "Content-Type": "text/javascript", "Service-Worker-Allowed": "/" });
      return res.end(src.replace("jarvis-shell-v1", "jarvis-shell-" + h.digest("hex").slice(0, 8)));
    } catch { return send(res, 404, { error: "Not found." }); }
  }
  try { const f = await readFile(path.join(PUB, p)); res.writeHead(200, { "Content-Type": MIME[path.extname(p)] || "application/octet-stream" }); res.end(f); }
  catch { send(res, 404, { error: "Not found." }); }
});
server.headersTimeout = 15000; server.requestTimeout = 30000;
export { server };
if (process.argv[1] === fileURLToPath(import.meta.url)) server.listen(+env("PORT", 3000), () => { console.log("JARVIS on :" + env("PORT", 3000)); configWarnings().forEach(m => console.warn("WARNING: " + m)); });
