// Provider adapter: any provider must expose stream({messages,model,temperature,signal}) -> async generator of text chunks.
export const openai = {
  name: "openai",
  configured: () => !!process.env.OPENAI_API_KEY,
  async *stream({ messages, model, temperature, signal }) {
    const base = process.env.OPENAI_BASE_URL || "https://api.openai.com/v1";
    const res = await fetch(`${base}/chat/completions`, {
      method: "POST", signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({ model, messages, temperature, stream: true }),
    });
    if (!res.ok) {
      const e = new Error("upstream"); e.status = res.status; throw e;
    }
    const dec = new TextDecoder(); let buf = "";
    for await (const chunk of res.body) {
      buf += dec.decode(chunk, { stream: true });
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line.startsWith("data:")) continue;
        const d = line.slice(5).trim();
        if (d === "[DONE]") return;
        try { const t = JSON.parse(d).choices?.[0]?.delta?.content; if (t) yield t; } catch {}
      }
    }
  },
};
