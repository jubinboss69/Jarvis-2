# JARVIS server (Phase 6)
Zero-dependency Node 18+ server. Serves the app and proxies chat to OpenAI. Your API key stays in env vars on the server.

## Run locally
    cp .env.example .env   # fill in OPENAI_API_KEY and ACCESS_CODE
    node --env-file=.env src/index.js
    npm test               # runs the server and client checks against mock OpenAI, weather and search services

## Deploy (Render / Railway / any Node host)
- Root directory: `server`, start command: `node src/index.js`
- Set env vars: OPENAI_API_KEY, ACCESS_CODE (required in public hosting, otherwise anyone can spend your key)
- Open the https URL on your phone. The app asks for the access code on the first message.
- Optional: set BRAVE_API_KEY to show web search results inside the app. Without it, search opens Google or DuckDuckGo instead.
- Weather uses Open-Meteo (no key). Translate and summarize use your OpenAI key.

## Security
See SECURITY.md. On a public host set `OPENAI_API_KEY`, a long `ACCESS_CODE`, and `TRUST_PROXY=1`. The server prints warnings at start-up if something is missing.

## Tests
    npm test              # server, client logic, tools, security
    npm run test:browser  # optional real-browser test (needs playwright + chromium)

## Installing on a phone
See PWA.md. Tests: `npm test` (192 checks) and `npm run test:browser` (131 real-browser checks, needs playwright).
